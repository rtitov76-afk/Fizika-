// Официальные источники. Проверено: сентябрь 2026.
export const DOCS_UPDATED = 'сентябрь 2026';

export const DOCS_LINKS = [
  {
    title: 'Ozon',
    links: [
      { name: 'База знаний Ozon Seller', url: 'https://seller-edu.ozon.ru/', desc: 'Официальная документация для продавцов: комиссии, логистика, реклама, правила' },
      { name: 'Комиссии и тарифы Ozon', url: 'https://seller-edu.ozon.ru/commissions-tariffs', desc: 'Актуальные комиссии по категориям и тарифы услуг (меняются — проверяйте здесь)' },
      { name: 'Личный кабинет Ozon Seller', url: 'https://seller.ozon.ru/', desc: 'Точные тарифы для ваших товаров — в калькуляторе и разделе «Тарифы» кабинета' },
      { name: 'Документация Ozon Seller API', url: 'https://docs.ozon.ru/api/seller/', desc: 'Официальное API: остатки, цены, заказы, аналитика, продвижение' }
    ]
  },
  {
    title: 'Wildberries',
    links: [
      { name: 'WB Партнёры (личный кабинет)', url: 'https://seller.wildberries.ru/', desc: 'Комиссии (КВВ), тарифы складов и коэффициенты — в разделе «Тарифы» кабинета' },
      { name: 'Справочный центр WB Партнёры', url: 'https://seller.wildberries.ru/help-center', desc: 'Официальные правила площадки, оферта, инструкции по работе' },
      { name: 'Документация WB API', url: 'https://dev.wildberries.ru/', desc: 'Портал разработчика: контент, цены, поставки, статистика, продвижение' }
    ]
  },
  {
    title: 'Государственное регулирование',
    links: [
      { name: '289-ФЗ о платформенной экономике', url: 'http://publication.pravo.gov.ru/document/0001202507310092', desc: 'Закон о регулировании маркетплейсов (основные положения — с 01.10.2026)' },
      { name: 'Честный ЗНАК', url: 'https://честныйзнак.рф/', desc: 'Обязательная маркировка товаров: категории, сроки, правила' },
      { name: 'ФНС России', url: 'https://www.nalog.gov.ru/', desc: 'Налоговые режимы (УСН, НПД), регистрация ИП/ООО' }
    ]
  },
  {
    title: 'Аналитика рынка',
    links: [
      { name: 'Data Insight', url: 'https://datainsight.ru/', desc: 'Исследования рынка e-commerce России: объёмы, динамика, доли площадок' },
      { name: 'Ассоциация компаний интернет-торговли (АКИТ)', url: 'https://akit.ru/', desc: 'Официальная статистика интернет-торговли' }
    ]
  }
];
