// Карта компетенций курса. Для каждой рассчитывается уровень 0–100.
export const COMPETENCIES = [
  { id: 'strategy', name: 'Marketplace Strategy', short: 'Стратегия' },
  { id: 'ozon', name: 'Ozon', short: 'Ozon' },
  { id: 'wb', name: 'Wildberries', short: 'Wildberries' },
  { id: 'unit_economics', name: 'Unit Economics', short: 'Юнит-экономика' },
  { id: 'pricing', name: 'Pricing', short: 'Ценообразование' },
  { id: 'advertising', name: 'Advertising', short: 'Реклама' },
  { id: 'seo', name: 'SEO', short: 'SEO' },
  { id: 'content', name: 'Content', short: 'Контент' },
  { id: 'analytics', name: 'Analytics', short: 'Аналитика' },
  { id: 'logistics', name: 'Logistics', short: 'Логистика' },
  { id: 'inventory', name: 'Inventory', short: 'Запасы' },
  { id: 'category', name: 'Category Management', short: 'Категорийный менеджмент' },
  { id: 'finance', name: 'Financial Management', short: 'Финансы' },
  { id: 'team', name: 'Team Management', short: 'Команда' }
];

export const COMPETENCY_MAP = Object.fromEntries(COMPETENCIES.map((c) => [c.id, c]));

export const LEVEL_SCALE = [
  { min: 93, label: 'Marketplace Expert' },
  { min: 85, label: 'Senior' },
  { min: 75, label: 'Middle+' },
  { min: 65, label: 'Middle' },
  { min: 50, label: 'Junior+' },
  { min: 0, label: 'Junior' }
];

export const DIAG_LEVELS = [
  { min: 81, label: 'Экспертный' },
  { min: 61, label: 'Продвинутый' },
  { min: 41, label: 'Средний' },
  { min: 21, label: 'Базовый' },
  { min: 0, label: 'Начальный' }
];

export function levelOf(score, scale = LEVEL_SCALE) {
  return scale.find((l) => score >= l.min)?.label ?? scale[scale.length - 1].label;
}
