// Достижения. check(state) — чистая функция от состояния.
import { MODULES, ALL_LESSONS } from './courseIndex.js';

function passedLessons(state) {
  return ALL_LESSONS.filter((l) => {
    const r = state.lessons[l.id];
    return r?.bestScore != null && r.bestScore >= (l.quiz?.pass ?? 70);
  }).length;
}

function passedModules(state) {
  return MODULES.filter((m) => {
    const allPassed = m.lessons.every((l) => {
      const r = state.lessons[l.id];
      return r?.bestScore != null && r.bestScore >= 70;
    });
    return allPassed && (state.modules[m.id]?.bestScore ?? 0) >= 70;
  }).length;
}

export const ACHIEVEMENTS = [
  { id: 'first_lesson', icon: '🥇', title: 'Первый шаг', desc: 'Пройден первый урок (тест ≥70%)', check: (s) => passedLessons(s) >= 1 },
  { id: 'first_module', icon: '📦', title: 'Первый модуль', desc: 'Полностью закрыт первый модуль вместе с тестом', check: (s) => passedModules(s) >= 1 },
  { id: 'diagnostic', icon: '🎯', title: 'Знаю свой уровень', desc: 'Пройдена входная диагностика', check: (s) => !!s.diagnostic },
  { id: 'five_modules', icon: '🚀', title: 'Разогнался', desc: 'Закрыто 5 модулей', check: (s) => passedModules(s) >= 5 },
  { id: 'ten_modules', icon: '🔥', title: 'Серийный ученик', desc: 'Закрыто 10 модулей', check: (s) => passedModules(s) >= 10 },
  { id: 'twenty_modules', icon: '🏔️', title: 'Марафонец', desc: 'Закрыто 20 модулей', check: (s) => passedModules(s) >= 20 },
  { id: 'all_modules', icon: '👑', title: 'Вся программа', desc: 'Закрыт 31 модуль', check: (s) => passedModules(s) >= MODULES.length },
  { id: 'perfect', icon: '💯', title: 'Перфекционист', desc: 'Тест сдан на 100%', check: (s) => Object.values(s.lessons).some((r) => r.bestScore === 100) || Object.values(s.modules).some((r) => r?.bestScore === 100) },
  { id: 'five_perfect', icon: '🌟', title: 'Снайпер', desc: '5 тестов на 100%', check: (s) => [...Object.values(s.lessons), ...Object.values(s.modules)].filter((r) => r?.bestScore === 100).length >= 5 },
  { id: 'comeback', icon: '💪', title: 'Работа над ошибками', desc: 'Пересдан ранее проваленный тест', check: (s) => Object.values(s.lessons).some((r) => (r.attempts || []).some((a) => a.score < 70) && r.bestScore >= 70) },
  { id: 'practice10', icon: '🛠️', title: 'Практик', desc: 'Выполнено 10 практических заданий', check: (s) => Object.values(s.practice || {}).filter((p) => p.done).length >= 10 },
  { id: 'trainer', icon: '🎮', title: 'Симулянт', desc: 'Пройден первый тренажёр-сценарий', check: (s) => Object.values(s.trainers || {}).some((t) => t.completed) },
  { id: 'all_trainers', icon: '🕹️', title: 'Гроссмейстер сценариев', desc: 'Пройдены все тренажёры', check: (s) => Object.values(s.trainers || {}).filter((t) => t.completed).length >= 10 },
  { id: 'notes5', icon: '✍️', title: 'Конспектор', desc: '5 заметок к урокам', check: (s) => Object.values(s.notes || {}).filter((n) => n?.text?.trim()).length >= 5 },
  { id: 'case', icon: '💼', title: 'Решатель кейсов', desc: 'Пройден итоговый бизнес-кейс', check: (s) => s.businessCase != null },
  { id: 'exam', icon: '🎓', title: 'Выпускник', desc: 'Итоговый экзамен сдан на ≥70%', check: (s) => (s.exam?.attempts || []).some((a) => a.percent >= 70) },
  { id: 'exam90', icon: '🏆', title: 'Эксперт', desc: 'Экзамен сдан на ≥90%', check: (s) => (s.exam?.attempts || []).some((a) => a.percent >= 90) },
  { id: 'project', icon: '🗺️', title: 'Стратег', desc: 'Завершён финальный проект — стратегия на 12 месяцев', check: (s) => s.finalProject?.done === true },
  { id: 'half', icon: '⛰️', title: 'Экватор', desc: 'Пройдена половина всех уроков', check: (s) => passedLessons(s) >= Math.ceil(ALL_LESSONS.length / 2) },
  { id: 'time10', icon: '⏱️', title: '10 часов в теме', desc: '10 часов активного обучения', check: (s) => (s.timeSpentSec || 0) >= 10 * 3600 }
];
