// Индекс курса (ДЕМО): открыты 3 модуля из 31.
import m00 from './modules/m00.js';
import m04 from './modules/m04.js';
import m07 from './modules/m07.js';
// Контент модулей лежит в /src/data/modules — по одному файлу на модуль.

export const MODULES = [m00, m04, m07].sort((a, b) => a.order - b.order);

// Плоский список уроков с обратной ссылкой на модуль
export const ALL_LESSONS = MODULES.flatMap((m) =>
  m.lessons.map((l) => ({ ...l, moduleId: m.id, moduleTitle: m.title }))
);

export const LESSON_MAP = Object.fromEntries(ALL_LESSONS.map((l) => [l.id, l]));
export const MODULE_MAP = Object.fromEntries(MODULES.map((m) => [m.id, m]));

// Банк вопросов модуля = банки уроков + дополнительный банк модуля
export function moduleBank(mod) {
  const lessonQs = mod.lessons.flatMap((l) => (l.quiz?.bank || []).map((q) => ({ ...q, lessonId: l.id })));
  return lessonQs.concat((mod.extraBank || []).map((q) => ({ ...q, lessonId: null })));
}

// Общий банк для итогового экзамена
export function allQuestions() {
  return MODULES.flatMap((m) => moduleBank(m).map((q) => ({ ...q, moduleId: m.id })));
}
