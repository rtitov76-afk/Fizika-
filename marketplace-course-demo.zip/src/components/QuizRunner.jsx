import React, { useState, useEffect, useRef } from 'react';
import { checkAnswer, scoreQuiz, gradeOf } from '../services/quiz.js';
import ProgressBar from './ProgressBar.jsx';

// Универсальный движок теста.
// props: questions (после sampleQuestions), title, pass, timeLimitSec?, onFinish(result)
export default function QuizRunner({ questions, title, pass = 70, timeLimitSec = null, onFinish }) {
  const [answers, setAnswers] = useState({});
  const [finished, setFinished] = useState(false);
  const [result, setResult] = useState(null);
  const [timeLeft, setTimeLeft] = useState(timeLimitSec);
  const startRef = useRef(Date.now());
  const finishedRef = useRef(false);

  useEffect(() => {
    if (!timeLimitSec) return;
    const t = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) { clearInterval(t); if (!finishedRef.current) finish(); return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function setAnswer(i, val) {
    setAnswers((a) => ({ ...a, [i]: val }));
  }

  function finish() {
    if (finishedRef.current) return;
    finishedRef.current = true;
    const ansArr = questions.map((_, i) => answers[i] ?? null);
    const res = scoreQuiz(questions, ansArr);
    const timeSec = Math.round((Date.now() - startRef.current) / 1000);
    const full = { ...res, timeSec, answers: ansArr, date: new Date().toISOString() };
    setResult(full);
    setFinished(true);
    onFinish?.(full);
    window.scrollTo(0, 0);
  }

  const answered = questions.filter((_, i) => answers[i] != null && answers[i] !== '').length;

  if (finished && result) {
    const grade = gradeOf(result.percent);
    const passed = result.percent >= pass;
    return (
      <div>
        <div className="panel" style={{ textAlign: 'center' }}>
          <h2>{passed ? '✅ Тест сдан' : '❌ Тест не сдан'}</h2>
          <div style={{ fontSize: '2.4rem', fontWeight: 800, color: passed ? 'var(--green)' : 'var(--red)' }}>
            {result.percent}%
          </div>
          <p>{result.correct} из {result.total} правильных · {Math.floor(result.timeSec / 60)} мин {result.timeSec % 60} сек</p>
          <span className={'badge ' + grade.cls}>{grade.label}</span>
          {!passed && <p style={{ color: 'var(--muted)', marginTop: 10 }}>Порог прохождения — {pass}%. Изучите разбор ошибок ниже и попробуйте ещё раз: вопросы будут другими.</p>}
        </div>
        <h3>Разбор ответов</h3>
        {questions.map((q, i) => {
          const ok = checkAnswer(q, result.answers[i]);
          return (
            <div className="quiz-q" key={q.id || i}>
              <div className="qnum">Вопрос {i + 1} · {ok ? '✅ верно' : '❌ ошибка'}{q.topic ? ` · тема: ${q.topic}` : ''}</div>
              {q.scenario && <div className="callout amber"><b>Ситуация:</b> {q.scenario}</div>}
              <p><b>{q.q}</b></p>
              <ReviewAnswer q={q} given={result.answers[i]} />
              {q.explain && <div className="quiz-explain">💡 {q.explain}</div>}
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div>
      {timeLimitSec != null && (
        <div className="timerbox" role="timer" aria-live="polite">
          <span>{title}</span>
          <strong>⏱ {Math.floor(timeLeft / 60)}:{String(timeLeft % 60).padStart(2, '0')}</strong>
        </div>
      )}
      <div className="panel">
        <ProgressBar percent={Math.round((answered / questions.length) * 100)} />
        <div style={{ fontSize: '.85rem', color: 'var(--muted)', marginTop: 6 }}>
          Отвечено: {answered} из {questions.length}
        </div>
      </div>
      {questions.map((q, i) => (
        <QuestionView key={q.id || i} q={q} idx={i} value={answers[i]} onChange={(v) => setAnswer(i, v)} />
      ))}
      <button className="btn" onClick={finish} disabled={answered < questions.length}>
        Завершить тест
      </button>
      {answered < questions.length && (
        <span style={{ marginLeft: 12, color: 'var(--muted)', fontSize: '.88rem' }}>Ответьте на все вопросы</span>
      )}
    </div>
  );
}

function QuestionView({ q, idx, value, onChange }) {
  return (
    <div className="quiz-q">
      <div className="qnum">Вопрос {idx + 1} · {typeLabel(q.type)}</div>
      {q.scenario && <div className="callout amber"><b>Ситуация:</b> {q.scenario}</div>}
      <p><b>{q.q}</b></p>
      {(q.type === 'single' || q.type === 'case') && (
        (q._order || q.options.map((_, i) => i)).map((oi) => (
          <label className={'quiz-opt' + (value === oi ? ' sel' : '')} key={oi}>
            <input type="radio" name={'q' + idx} checked={value === oi} onChange={() => onChange(oi)} />
            <span>{q.options[oi]}</span>
          </label>
        ))
      )}
      {q.type === 'multi' && (
        (q._order || q.options.map((_, i) => i)).map((oi) => {
          const arr = Array.isArray(value) ? value : [];
          const sel = arr.includes(oi);
          return (
            <label className={'quiz-opt' + (sel ? ' sel' : '')} key={oi}>
              <input type="checkbox" checked={sel}
                onChange={() => onChange(sel ? arr.filter((x) => x !== oi) : [...arr, oi])} />
              <span>{q.options[oi]}</span>
            </label>
          );
        })
      )}
      {q.type === 'calc' && (
        <div>
          <input className="quiz-input" inputMode="decimal" placeholder={'Ответ' + (q.unit ? ', ' + q.unit : '')}
            value={value ?? ''} onChange={(e) => onChange(e.target.value)} aria-label="Числовой ответ" />
          {q.hint && <div style={{ fontSize: '.82rem', color: 'var(--muted)', marginTop: 4 }}>Подсказка: {q.hint}</div>}
        </div>
      )}
      {q.type === 'order' && <OrderQuestion q={q} value={value} onChange={onChange} />}
      {q.type === 'match' && <MatchQuestion q={q} value={value} onChange={onChange} />}
    </div>
  );
}

function OrderQuestion({ q, value, onChange }) {
  const current = Array.isArray(value) ? value : (q._order || q.items.map((_, i) => i));
  useEffect(() => { if (!Array.isArray(value)) onChange(current); /* фиксация стартового порядка */ }, []); // eslint-disable-line
  function move(pos, dir) {
    const arr = [...current];
    const np = pos + dir;
    if (np < 0 || np >= arr.length) return;
    [arr[pos], arr[np]] = [arr[np], arr[pos]];
    onChange(arr);
  }
  return (
    <div>
      <p style={{ fontSize: '.85rem', color: 'var(--muted)' }}>Расставьте в правильном порядке (сверху — первый шаг):</p>
      {current.map((itemIdx, pos) => (
        <div className="order-item" key={itemIdx}>
          <button onClick={() => move(pos, -1)} aria-label="Выше">↑</button>
          <button onClick={() => move(pos, 1)} aria-label="Ниже">↓</button>
          <span><b>{pos + 1}.</b> {q.items[itemIdx]}</span>
        </div>
      ))}
    </div>
  );
}

function MatchQuestion({ q, value, onChange }) {
  const map = value && typeof value === 'object' ? value : {};
  const rightOrder = q._rightOrder || q.pairs.map((_, i) => i);
  return (
    <div>
      <p style={{ fontSize: '.85rem', color: 'var(--muted)' }}>Установите соответствие:</p>
      {q.pairs.map((p, li) => (
        <div className="match-row" key={li}>
          <div><b>{p.left}</b></div>
          <select value={map[li] ?? ''} onChange={(e) => onChange({ ...map, [li]: e.target.value === '' ? undefined : Number(e.target.value) })}>
            <option value="">— выберите —</option>
            {rightOrder.map((ri) => (
              <option key={ri} value={ri}>{q.pairs[ri].right}</option>
            ))}
          </select>
        </div>
      ))}
    </div>
  );
}

function ReviewAnswer({ q, given }) {
  if (q.type === 'single' || q.type === 'case') {
    return (
      <div>
        {q.options.map((o, i) => (
          <div key={i} className={'quiz-opt' + (i === q.correct ? ' correct' : given === i ? ' wrongsel' : '')}>
            <span>{i === q.correct ? '✅' : given === i ? '❌' : '·'} {o}</span>
          </div>
        ))}
      </div>
    );
  }
  if (q.type === 'multi') {
    const arr = Array.isArray(given) ? given : [];
    return (
      <div>
        {q.options.map((o, i) => (
          <div key={i} className={'quiz-opt' + (q.correct.includes(i) ? ' correct' : arr.includes(i) ? ' wrongsel' : '')}>
            <span>{q.correct.includes(i) ? '✅' : arr.includes(i) ? '❌' : '·'} {o}</span>
          </div>
        ))}
      </div>
    );
  }
  if (q.type === 'calc') {
    return <p>Ваш ответ: <b>{given ?? '—'}</b> · Правильный: <b>{q.answer}{q.unit ? ' ' + q.unit : ''}</b></p>;
  }
  if (q.type === 'order') {
    return (
      <div>
        <p>Правильный порядок:</p>
        <ol>{q.items.map((it, i) => <li key={i}>{it}</li>)}</ol>
      </div>
    );
  }
  if (q.type === 'match') {
    return (
      <div>
        <p>Правильные соответствия:</p>
        <ul>{q.pairs.map((p, i) => <li key={i}><b>{p.left}</b> → {p.right}</li>)}</ul>
      </div>
    );
  }
  return null;
}

function typeLabel(t) {
  return { single: 'один ответ', multi: 'несколько ответов', calc: 'расчёт', order: 'последовательность', match: 'соответствие', case: 'мини-кейс' }[t] || '';
}
