import React from 'react';

export default function ProgressBar({ percent, color }) {
  const p = Math.max(0, Math.min(100, percent ?? 0));
  const cls = color || (p >= 70 ? 'green' : p >= 40 ? '' : p > 0 ? 'amber' : '');
  return (
    <div className={'pbar ' + cls} role="progressbar" aria-valuenow={p} aria-valuemin={0} aria-valuemax={100}>
      <div style={{ width: p + '%' }} />
    </div>
  );
}
