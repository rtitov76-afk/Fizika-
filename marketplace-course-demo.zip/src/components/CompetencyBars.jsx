import React from 'react';
import { COMPETENCIES } from '../data/competencies.js';
import ProgressBar from './ProgressBar.jsx';

export default function CompetencyBars({ scores }) {
  return (
    <div>
      {COMPETENCIES.map((c) => {
        const v = scores[c.id];
        return (
          <div key={c.id} style={{ marginBottom: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.88rem', marginBottom: 3 }}>
              <span>{c.name} <span style={{ color: 'var(--muted)' }}>· {c.short}</span></span>
              <b>{v == null ? '—' : v + '/100'}</b>
            </div>
            <ProgressBar percent={v ?? 0} />
          </div>
        );
      })}
      <p style={{ fontSize: '.8rem', color: 'var(--muted)' }}>«—» — по компетенции ещё нет данных: пройдите уроки и тесты соответствующих модулей.</p>
    </div>
  );
}
