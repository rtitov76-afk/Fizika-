// Хранилище прогресса. Версия 1 — localStorage.
// Архитектура: единый объект состояния + слой доступа.
// Для будущего подключения Supabase/Firebase достаточно заменить load/save
// на асинхронные вызовы API, интерфейс остальных функций не меняется.

const KEY = 'mpcourse_v1';

const DEFAULT_STATE = {
  version: 1,
  profile: { name: '', createdAt: null },
  diagnostic: null, // { date, score, total, percent, byCompetency: {compId: percent}, level }
  lessons: {},      // lessonId -> { status, studiedAt, bestScore, attempts: [] }
  modules: {},      // moduleId -> { bestScore, attempts: [], feedback: null }
  practice: {},     // lessonId -> { done: true, answer, date }
  notes: {},        // lessonId -> { text, updatedAt }
  bookmarks: [],    // [lessonId]
  lastLocation: null, // { moduleId, lessonId }
  exam: { attempts: [] }, // { date, score, percent, correct, total, timeSec, byKind, byCompetency, wrong }
  businessCase: null, // { date, percent, steps: [...] }
  finalProject: null, // { date, sections: {...} }
  courseFeedback: null,
  trainers: {},     // trainerId -> { attempts: [{date, percent}] }
  activity: [],     // [{ date, type, label, value }]
  achievements: [], // [achievementId]
  timeSpentSec: 0
};

export function loadState() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return structuredClone(DEFAULT_STATE);
    const parsed = JSON.parse(raw);
    return { ...structuredClone(DEFAULT_STATE), ...parsed };
  } catch {
    return structuredClone(DEFAULT_STATE);
  }
}

export function saveState(state) {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch (e) {
    console.error('Не удалось сохранить прогресс', e);
  }
}

export function updateState(mutator) {
  const s = loadState();
  mutator(s);
  saveState(s);
  return s;
}

export function resetState() {
  localStorage.removeItem(KEY);
}

export function exportState() {
  const s = loadState();
  const blob = new Blob([JSON.stringify(s, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `marketplace-course-progress-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export function importState(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (!data || typeof data !== 'object' || data.version !== 1) {
          reject(new Error('Файл не похож на резервную копию прогресса этого курса.'));
          return;
        }
        saveState({ ...structuredClone(DEFAULT_STATE), ...data });
        resolve(true);
      } catch (e) {
        reject(new Error('Не удалось прочитать файл: ' + e.message));
      }
    };
    reader.onerror = () => reject(new Error('Ошибка чтения файла'));
    reader.readAsText(file);
  });
}

export function logActivity(type, label, value) {
  updateState((s) => {
    s.activity.unshift({ date: new Date().toISOString(), type, label, value: value ?? null });
    if (s.activity.length > 400) s.activity.length = 400;
  });
}

export function addTime(seconds) {
  updateState((s) => {
    s.timeSpentSec = (s.timeSpentSec || 0) + seconds;
  });
}
