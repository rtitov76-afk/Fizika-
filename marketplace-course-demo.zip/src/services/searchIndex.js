// Полнотекстовый поиск по урокам, глоссарию, формулам, кейсам и вопросам тестов.
import { MODULES, ALL_LESSONS } from '../data/courseIndex.js';
import { GLOSSARY } from '../data/glossary.js';

let INDEX = null;

function sectionText(s) {
  const parts = [];
  if (s.title) parts.push(s.title);
  if (s.text) parts.push(s.text);
  if (s.formula) parts.push(s.formula);
  if (s.legend) parts.push(s.legend);
  if (s.items) s.items.forEach((it) => parts.push(typeof it === 'string' ? it : `${it.term ?? ''} ${it.def ?? ''}`));
  return parts.join(' ');
}

export function buildIndex() {
  if (INDEX) return INDEX;
  INDEX = [];
  ALL_LESSONS.forEach((l) => {
    (l.sections || []).forEach((s, i) => {
      const kindMap = { formula: 'Формула', case: 'Кейс', example: 'Пример', calcExample: 'Расчёт' };
      INDEX.push({
        kind: kindMap[s.type] || 'Урок',
        title: `${l.moduleTitle} → ${l.title}${s.title ? ' → ' + s.title : ''}`,
        text: sectionText(s),
        link: `/lesson/${l.id}`,
        key: `${l.id}-s${i}`
      });
    });
    (l.quiz?.bank || []).forEach((q) => {
      INDEX.push({ kind: 'Вопрос теста', title: `${l.title}`, text: q.q, link: `/lesson/${l.id}`, key: q.id });
    });
  });
  MODULES.forEach((m) => (m.extraBank || []).forEach((q) => {
    INDEX.push({ kind: 'Вопрос теста', title: m.title, text: q.q, link: `/module/${m.id}`, key: q.id });
  }));
  GLOSSARY.forEach((g, i) => {
    INDEX.push({ kind: 'Термин', title: g.term, text: g.def + ' ' + (g.formula || ''), link: '/glossary', key: 'g' + i });
  });
  return INDEX;
}

export function search(query) {
  if (!query || query.trim().length < 2) return [];
  const q = query.trim().toLowerCase();
  const words = q.split(/\s+/).filter(Boolean);
  const idx = buildIndex();
  const scored = [];
  idx.forEach((e) => {
    const title = e.title.toLowerCase();
    const text = e.text.toLowerCase();
    let score = 0;
    words.forEach((w) => {
      if (title.includes(w)) score += 5;
      if (text.includes(w)) score += 2;
    });
    if (title === q || title.includes(q)) score += 6;
    if (score > 0) scored.push({ ...e, score });
  });
  return scored.sort((a, b) => b.score - a.score).slice(0, 60);
}

export function highlight(text, query, span = 160) {
  const q = query.trim().toLowerCase();
  const i = text.toLowerCase().indexOf(q.split(/\s+/)[0] || q);
  if (i < 0) return text.slice(0, span) + (text.length > span ? '…' : '');
  const start = Math.max(0, i - 50);
  return (start > 0 ? '…' : '') + text.slice(start, start + span) + (text.length > start + span ? '…' : '');
}
