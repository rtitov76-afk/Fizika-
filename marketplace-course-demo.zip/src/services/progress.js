// Логика прогресса, компетенций, слабых тем, адаптивных рекомендаций и итоговой оценки.
import { COMPETENCIES, levelOf } from '../data/competencies.js';
import { MODULES, ALL_LESSONS } from '../data/courseIndex.js';

export const PASS = 70;

// Статусы урока: not_started | started | studied | test_failed | passed
export function lessonStatus(state, lesson) {
  const rec = state.lessons[lesson.id];
  if (!rec) return 'not_started';
  if (rec.bestScore != null) {
    return rec.bestScore >= (lesson.quiz?.pass ?? PASS) ? 'passed' : 'test_failed';
  }
  if (rec.studiedAt) return 'studied';
  return 'started';
}

export const STATUS_META = {
  not_started: { label: 'Не начато', icon: '○', cls: 'st-none' },
  started: { label: 'Начато', icon: '◔', cls: 'st-started' },
  studied: { label: 'Материал изучен', icon: '◑', cls: 'st-studied' },
  test_failed: { label: 'Тест не сдан', icon: '✕', cls: 'st-failed' },
  passed: { label: 'Пройдено', icon: '✓', cls: 'st-passed' }
};

export function moduleProgress(state, mod) {
  const lessons = mod.lessons;
  const passed = lessons.filter((l) => lessonStatus(state, l) === 'passed').length;
  const modRec = state.modules[mod.id];
  const testPassed = modRec?.bestScore != null && modRec.bestScore >= PASS;
  return {
    passed,
    total: lessons.length,
    percent: Math.round((passed / Math.max(lessons.length, 1)) * 100),
    testScore: modRec?.bestScore ?? null,
    testPassed
  };
}

export function overallProgress(state) {
  const total = ALL_LESSONS.length;
  const passed = ALL_LESSONS.filter((l) => lessonStatus(state, l) === 'passed').length;
  return { passed, total, percent: total ? Math.round((passed / total) * 100) : 0 };
}

// Компетенции: среднее лучших результатов уроков и модульных тестов, помеченных этой компетенцией.
export function competencyScores(state) {
  const acc = Object.fromEntries(COMPETENCIES.map((c) => [c.id, { sum: 0, n: 0 }]));
  ALL_LESSONS.forEach((l) => {
    const rec = state.lessons[l.id];
    if (rec?.bestScore == null) return;
    (l.competencies || []).forEach((cid) => {
      if (acc[cid]) { acc[cid].sum += rec.bestScore; acc[cid].n++; }
    });
  });
  MODULES.forEach((m) => {
    const rec = state.modules[m.id];
    if (rec?.bestScore == null) return;
    (m.competencies || [m.competency]).filter(Boolean).forEach((cid) => {
      if (acc[cid]) { acc[cid].sum += rec.bestScore; acc[cid].n++; }
    });
  });
  const res = {};
  COMPETENCIES.forEach((c) => {
    const a = acc[c.id];
    res[c.id] = a.n ? Math.round(a.sum / a.n) : null;
  });
  return res;
}

export function platformScore(state, platform) {
  // platform: 'ozon' | 'wb'
  let sum = 0, n = 0;
  ALL_LESSONS.forEach((l) => {
    const rec = state.lessons[l.id];
    if (rec?.bestScore == null) return;
    if (l.platform === platform || l.platform === 'both' || (l.competencies || []).includes(platform)) {
      sum += rec.bestScore; n++;
    }
  });
  return n ? Math.round(sum / n) : null;
}

// Слабые темы: уроки с лучшим результатом < 70% либо повторяющимися ошибками по topic.
export function weakTopics(state) {
  const weak = [];
  ALL_LESSONS.forEach((l) => {
    const rec = state.lessons[l.id];
    if (!rec || rec.bestScore == null) return;
    if (rec.bestScore < (l.quiz?.pass ?? PASS)) {
      weak.push({ lessonId: l.id, moduleId: l.moduleId, title: l.title, score: rec.bestScore, reason: 'score' });
      return;
    }
    // повторяющиеся ошибки по одной теме в 2+ попытках
    const topicFails = {};
    (rec.attempts || []).forEach((a) => {
      const seen = new Set();
      (a.wrong || []).forEach((w) => {
        if (w.topic && !seen.has(w.topic)) { seen.add(w.topic); topicFails[w.topic] = (topicFails[w.topic] || 0) + 1; }
      });
    });
    const repeated = Object.entries(topicFails).filter(([, n]) => n >= 2).map(([t]) => t);
    if (repeated.length) {
      weak.push({ lessonId: l.id, moduleId: l.moduleId, title: l.title, score: rec.bestScore, reason: 'topics', topics: repeated });
    }
  });
  return weak.sort((a, b) => a.score - b.score);
}

export function strongTopics(state) {
  return ALL_LESSONS
    .map((l) => ({ l, rec: state.lessons[l.id] }))
    .filter(({ rec }) => rec?.bestScore != null && rec.bestScore >= 85)
    .map(({ l, rec }) => ({ lessonId: l.id, moduleId: l.moduleId, title: l.title, score: rec.bestScore }))
    .sort((a, b) => b.score - a.score);
}

// Адаптивная рекомендация следующей темы.
// Учитывает: порядок модулей (зависимости), результаты, слабые темы, диагностику.
export function nextRecommendation(state) {
  const weak = weakTopics(state);
  // 1) если есть слабая тема в уже открытом материале — повторить её
  if (weak.length) {
    const w = weak[0];
    return { type: 'repeat', lessonId: w.lessonId, moduleId: w.moduleId, title: w.title, reason: `Результат ${w.score}% — ниже порога. Рекомендуем повторить.` };
  }
  // 2) диагностика: если по компетенции низкий входной результат, приоритет модулям этой компетенции
  const diag = state.diagnostic?.byCompetency || null;
  const ordered = [...MODULES].sort((a, b) => a.order - b.order);
  let candidate = null;
  for (const m of ordered) {
    const next = m.lessons.find((l) => lessonStatus(state, l) !== 'passed');
    if (next) { candidate = { m, l: next }; break; }
  }
  if (!candidate) return { type: 'done', title: 'Курс пройден — переходите к итоговому экзамену', reason: '' };
  if (diag) {
    // ищем среди ещё не пройденных модулей тот, чья компетенция самая слабая по диагностике
    const unfinished = ordered.filter((m) => m.lessons.some((l) => lessonStatus(state, l) !== 'passed'));
    const scored = unfinished
      .map((m) => ({ m, d: diag[m.competency] ?? 50 }))
      .sort((a, b) => a.d - b.d);
    if (scored.length && scored[0].d < 50 && scored[0].m.order <= candidate.m.order + 4) {
      const m = scored[0].m;
      const l = m.lessons.find((x) => lessonStatus(state, x) !== 'passed');
      return { type: 'next', lessonId: l.id, moduleId: m.id, title: l.title, reason: `По входной диагностике «${m.title}» — ваша слабая зона (${scored[0].d}%).` };
    }
  }
  return { type: 'next', lessonId: candidate.l.id, moduleId: candidate.m.id, title: candidate.l.title, reason: 'Следующая тема по программе курса.' };
}

// Средние баллы по группам тестов
function avg(arr) { return arr.length ? Math.round(arr.reduce((a, b) => a + b, 0) / arr.length) : 0; }

export function scoreBlocks(state) {
  const lessonScores = ALL_LESSONS.map((l) => state.lessons[l.id]?.bestScore).filter((x) => x != null);
  const moduleScores = MODULES.map((m) => state.modules[m.id]?.bestScore).filter((x) => x != null);
  const practiceDone = ALL_LESSONS.filter((l) => state.practice[l.id]?.done).length;
  const practicePct = ALL_LESSONS.length ? Math.round((practiceDone / ALL_LESSONS.length) * 100) : 0;
  const casePct = state.businessCase?.percent ?? 0;
  const examBest = state.exam.attempts.length ? Math.max(...state.exam.attempts.map((a) => a.percent)) : 0;
  return {
    lessonTests: avg(lessonScores),
    moduleTests: avg(moduleScores),
    practice: practicePct,
    businessCase: casePct,
    finalExam: examBest
  };
}

// Final Score = Lesson×0.20 + Module×0.25 + Practice×0.20 + Case×0.15 + Exam×0.20
export function finalScore(state) {
  const b = scoreBlocks(state);
  const score = Math.round(
    b.lessonTests * 0.20 + b.moduleTests * 0.25 + b.practice * 0.20 + b.businessCase * 0.15 + b.finalExam * 0.20
  );
  return { ...b, score, level: levelOf(score) };
}

export function isCourseComplete(state) {
  const op = overallProgress(state);
  const examOk = state.exam.attempts.some((a) => a.percent >= PASS);
  return op.percent >= 80 && examOk;
}
