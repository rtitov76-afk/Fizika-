// Движок тестирования: выборка из банка вопросов, проверка ответов, оценка.

export const GRADE_SCALE = [
  { min: 95, label: 'Экспертное владение', cls: 'grade-expert' },
  { min: 85, label: 'Продвинутый уровень', cls: 'grade-adv' },
  { min: 70, label: 'Уверенное владение', cls: 'grade-good' },
  { min: 50, label: 'Базовое понимание', cls: 'grade-base' },
  { min: 0, label: 'Тема не освоена', cls: 'grade-fail' }
];

export function gradeOf(percent) {
  return GRADE_SCALE.find((g) => percent >= g.min);
}

export function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// Случайная выборка из банка. При повторных попытках вопросы будут отличаться.
export function sampleQuestions(bank, count) {
  const picked = shuffle(bank).slice(0, Math.min(count, bank.length));
  // Перемешиваем варианты, сохраняя ссылку на правильные через значения
  return picked.map((q) => {
    if ((q.type === 'single' || q.type === 'multi' || q.type === 'case') && q.options) {
      const idx = q.options.map((_, i) => i);
      const order = shuffle(idx);
      return { ...q, _order: order };
    }
    if (q.type === 'order' && q.items) {
      return { ...q, _order: shuffle(q.items.map((_, i) => i)) };
    }
    if (q.type === 'match' && q.pairs) {
      return { ...q, _rightOrder: shuffle(q.pairs.map((_, i) => i)) };
    }
    return q;
  });
}

// Проверка одного ответа. Возвращает true/false.
export function checkAnswer(q, answer) {
  if (answer == null) return false;
  switch (q.type) {
    case 'single':
    case 'case':
      return answer === q.correct;
    case 'multi': {
      if (!Array.isArray(answer)) return false;
      const a = [...answer].sort().join(',');
      const c = [...q.correct].sort().join(',');
      return a === c;
    }
    case 'calc': {
      const num = parseFloat(String(answer).replace(',', '.').replace(/\s/g, ''));
      if (Number.isNaN(num)) return false;
      const tol = q.tolerance ?? Math.max(Math.abs(q.answer) * 0.02, 0.01);
      return Math.abs(num - q.answer) <= tol;
    }
    case 'order': {
      if (!Array.isArray(answer)) return false;
      return answer.join(',') === q.items.map((_, i) => i).join(',');
    }
    case 'match': {
      if (!answer || typeof answer !== 'object') return false;
      return q.pairs.every((_, i) => answer[i] === i);
    }
    default:
      return false;
  }
}

export function scoreQuiz(questions, answers) {
  let correct = 0;
  const wrong = [];
  questions.forEach((q, i) => {
    if (checkAnswer(q, answers[i])) correct++;
    else wrong.push({ id: q.id, topic: q.topic || null, q: q.q });
  });
  const percent = questions.length ? Math.round((correct / questions.length) * 100) : 0;
  return { correct, total: questions.length, percent, wrong };
}

// Сборка итогового экзамена из банков всех модулей по структуре:
// 20% теория, 30% расчёты, 30% кейсы, 20% управленческие решения.
export function buildExam(allQuestions, total = 90) {
  const byKind = { theory: [], calcq: [], caseq: [], mgmt: [] };
  allQuestions.forEach((q) => {
    const kind = q.kind || (q.type === 'calc' ? 'calcq' : q.type === 'case' ? 'caseq' : 'theory');
    (byKind[kind] || byKind.theory).push(q);
  });
  const plan = [
    ['theory', Math.round(total * 0.2)],
    ['calcq', Math.round(total * 0.3)],
    ['caseq', Math.round(total * 0.3)],
    ['mgmt', Math.round(total * 0.2)]
  ];
  let exam = [];
  const used = new Set();
  plan.forEach(([kind, n]) => {
    const pool = shuffle(byKind[kind]).filter((q) => !used.has(q.id));
    const take = pool.slice(0, n);
    take.forEach((q) => used.add(q.id));
    exam = exam.concat(take);
  });
  // добор до total из любых оставшихся
  if (exam.length < total) {
    const rest = shuffle(allQuestions).filter((q) => !used.has(q.id)).slice(0, total - exam.length);
    exam = exam.concat(rest);
  }
  return sampleQuestions(shuffle(exam), exam.length);
}
