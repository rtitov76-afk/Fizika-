import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { loadState } from '../services/storage.js';
import { overallProgress, finalScore, competencyScores, platformScore, scoreBlocks } from '../services/progress.js';
import { ACHIEVEMENTS } from '../data/achievements.js';
import CompetencyBars from '../components/CompetencyBars.jsx';
import StatCard from '../components/StatCard.jsx';

export default function AnalyticsPage() {
  const state = useMemo(() => loadState(), []);
  const op = overallProgress(state);
  const fs = finalScore(state);
  const comp = competencyScores(state);
  const ozon = platformScore(state, 'ozon');
  const wb = platformScore(state, 'wb');
  const blocks = scoreBlocks(state);
  const timeH = Math.floor((state.timeSpentSec || 0) / 3600);
  const timeM = Math.round(((state.timeSpentSec || 0) % 3600) / 60);
  const attempts = (state.activity || []).filter((a) => ['quiz', 'module_test', 'exam'].includes(a.type));
  const avgScore = attempts.length ? Math.round(attempts.reduce((s, a) => s + (a.value || 0), 0) / attempts.length) : null;
  const unlocked = ACHIEVEMENTS.filter((a) => a.check(state));
  const locked = ACHIEVEMENTS.filter((a) => !a.check(state));

  // Динамика: средний балл по неделям
  const byWeek = {};
  attempts.forEach((a) => {
    const d = new Date(a.date);
    const wk = `${d.getFullYear()}-${String(Math.ceil((d.getDate() + new Date(d.getFullYear(), d.getMonth(), 1).getDay()) / 7)).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}`;
    byWeek[wk] = byWeek[wk] || [];
    byWeek[wk].push(a.value || 0);
  });
  const weeks = Object.entries(byWeek).slice(-8);

  return (
    <div>
      <h1>Моя аналитика</h1>

      <div className="grid4">
        <StatCard label="Marketplace Score" value={fs.score + '/100'} sub={fs.level} />
        <StatCard label="Прогресс" value={op.percent + '%'} sub={`${op.passed}/${op.total} уроков`} />
        <StatCard label="Средний балл тестов" value={avgScore == null ? '—' : avgScore + '%'} sub={`${attempts.length} попыток`} />
        <StatCard label="Время в курсе" value={timeH + ' ч ' + timeM + ' м'} sub="активное время" />
      </div>

      <div className="grid2">
        <div className="panel">
          <h3>Карта компетенций (14 направлений)</h3>
          <CompetencyBars scores={comp} />
        </div>
        <div>
          <div className="panel">
            <h3>Платформенные баллы</h3>
            <div className="lesson-list-item"><span>Ozon Score</span><b>{ozon == null ? '—' : ozon + '/100'}</b></div>
            <div className="lesson-list-item"><span>Wildberries Score</span><b>{wb == null ? '—' : wb + '/100'}</b></div>
            <p style={{ fontSize: '.8rem', color: 'var(--muted)' }}>Считаются по урокам и тестам, привязанным к каждой площадке.</p>
          </div>
          <div className="panel">
            <h3>Блоки итоговой оценки</h3>
            {[['Тесты уроков (20%)', blocks.lessonTests], ['Тесты модулей (25%)', blocks.moduleTests],
              ['Практика (20%)', blocks.practice], ['Бизнес-кейс (15%)', blocks.businessCase], ['Экзамен (20%)', blocks.finalExam]].map(([l, v]) => (
              <div key={l} className="lesson-list-item"><span style={{ fontSize: '.9rem' }}>{l}</span><b>{v}%</b></div>
            ))}
          </div>
        </div>
      </div>

      {weeks.length > 0 && (
        <div className="panel">
          <h3>Динамика среднего балла по неделям</h3>
          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, height: 140, paddingTop: 10 }}>
            {weeks.map(([wk, vals]) => {
              const avg = Math.round(vals.reduce((a, b) => a + b, 0) / vals.length);
              return (
                <div key={wk} style={{ flex: 1, textAlign: 'center' }}>
                  <div style={{ fontSize: '.75rem' }}>{avg}%</div>
                  <div style={{ background: avg >= 70 ? 'var(--green, #16a34a)' : 'var(--red, #dc2626)', height: Math.max(6, avg), borderRadius: 4, opacity: .85 }} />
                  <div style={{ fontSize: '.68rem', color: 'var(--muted)', marginTop: 4 }}>{wk}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="panel">
        <h3>🏅 Достижения ({unlocked.length}/{ACHIEVEMENTS.length})</h3>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {unlocked.map((a) => <span key={a.id} className="ach on" title={a.desc}>{a.icon} {a.title}</span>)}
          {locked.map((a) => <span key={a.id} className="ach" title={a.desc}>{a.icon} {a.title}</span>)}
        </div>
      </div>

      <p><Link to="/report">→ Weekly Business Review</Link> · <Link to="/results">→ История результатов</Link></p>
    </div>
  );
}
