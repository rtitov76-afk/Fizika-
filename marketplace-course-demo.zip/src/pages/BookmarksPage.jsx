import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { loadState } from '../services/storage.js';
import { LESSON_MAP, MODULE_MAP } from '../data/courseIndex.js';

export default function BookmarksPage() {
  const state = useMemo(() => loadState(), []);
  const bms = (state.bookmarks || []).map((id) => LESSON_MAP[id]).filter(Boolean);
  return (
    <div>
      <h1>Закладки</h1>
      {bms.length === 0 && (
        <p className="panel">Закладок пока нет. Нажмите «☆ В закладки» в любом уроке, чтобы быстро возвращаться к важным темам.</p>
      )}
      {bms.map((l) => (
        <div className="lesson-list-item panel" key={l.id} style={{ padding: '12px 16px' }}>
          <div>
            <Link to={`/lesson/${l.id}`}><b>{l.title}</b></Link>
            <div style={{ fontSize: '.8rem', color: 'var(--muted)' }}>{MODULE_MAP[l.moduleId]?.title}</div>
          </div>
          <span className="badge st-none">★</span>
        </div>
      ))}
    </div>
  );
}
