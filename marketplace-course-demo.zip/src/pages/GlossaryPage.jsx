import React, { useMemo, useState } from 'react';
import { GLOSSARY } from '../data/glossary.js';

export default function GlossaryPage() {
  const [q, setQ] = useState('');
  const sorted = useMemo(() => [...GLOSSARY].sort((a, b) => a.term.localeCompare(b.term, 'ru')), []);
  const filtered = q.trim()
    ? sorted.filter((g) => (g.term + ' ' + g.def).toLowerCase().includes(q.toLowerCase()))
    : sorted;
  const letters = {};
  filtered.forEach((g) => {
    const L = g.term[0].toUpperCase();
    letters[L] = letters[L] || [];
    letters[L].push(g);
  });
  return (
    <div>
      <h1>Глоссарий</h1>
      <p style={{ color: 'var(--muted)' }}>{GLOSSARY.length} терминов маркетплейс-бизнеса: метрики, логистика, реклама, финансы.</p>
      <input className="searchbox" placeholder="Поиск термина…" value={q} onChange={(e) => setQ(e.target.value)} />
      {Object.entries(letters).map(([L, items]) => (
        <div key={L}>
          <h2 style={{ borderBottom: '2px solid var(--border)', paddingBottom: 4 }}>{L}</h2>
          {items.map((g) => (
            <div className="panel" key={g.term} style={{ padding: '12px 16px' }}>
              <b>{g.term}</b>
              <p style={{ margin: '4px 0 0', fontSize: '.92rem' }}>{g.def}</p>
              {g.formula && <div className="formula-box" style={{ marginTop: 8 }}>{g.formula}</div>}
            </div>
          ))}
        </div>
      ))}
      {filtered.length === 0 && <p className="panel">Ничего не найдено по запросу «{q}».</p>}
    </div>
  );
}
