import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { BUSINESS_CASE } from '../data/businessCase.js';
import { sampleQuestions } from '../services/quiz.js';
import { updateState, logActivity, loadState } from '../services/storage.js';
import QuizRunner from '../components/QuizRunner.jsx';

export default function BusinessCasePage() {
  const [state, setState] = useState(() => loadState());
  const [stepIdx, setStepIdx] = useState(-1); // -1 = intro / results
  const [interlude, setInterlude] = useState(false);
  const [stepQuestions, setStepQuestions] = useState(null);
  const [acc, setAcc] = useState({ correct: 0, total: 0 });
  const saved = state.businessCase;
  const steps = BUSINESS_CASE.steps;

  function startStep(i) {
    setInterlude(false);
    setStepIdx(i);
    setStepQuestions(sampleQuestions(steps[i].questions, steps[i].questions.length));
  }

  function onStepFinish(res) {
    const next = { correct: acc.correct + res.correct, total: acc.total + res.total };
    setAcc(next);
    setStepQuestions(null);
    if (stepIdx + 1 < steps.length) {
      setInterlude(true);
    } else {
      const percent = Math.round((next.correct / next.total) * 100);
      const s = updateState((st) => {
        st.businessCase = { percent, correct: next.correct, total: next.total, date: new Date().toISOString() };
      });
      logActivity('case', 'Итоговый бизнес-кейс', percent);
      setState(s);
      setStepIdx(-1);
      setAcc({ correct: 0, total: 0 });
    }
  }

  if (interlude) {
    const nextI = stepIdx + 1;
    return (
      <div>
        <h1>{BUSINESS_CASE.title}</h1>
        <div className="panel">
          <p>Этап {stepIdx + 1} завершён. Всего верных ответов: <b>{acc.correct} из {acc.total}</b>.</p>
          <button className="btn" onClick={() => startStep(nextI)}>Этап {nextI + 1}: {steps[nextI].title} →</button>
        </div>
      </div>
    );
  }

  if (stepIdx >= 0 && stepQuestions) {
    const step = steps[stepIdx];
    return (
      <div>
        <h1>{BUSINESS_CASE.title}</h1>
        <div className="panel">
          <h3>Этап {stepIdx + 1} из {steps.length}. {step.title}</h3>
          <p style={{ whiteSpace: 'pre-line' }}>{step.text}</p>
        </div>
        <QuizRunner
          key={stepIdx}
          questions={stepQuestions}
          title={`Этап ${stepIdx + 1}: ${step.title}`}
          pass={70}
          onFinish={onStepFinish}
        />
      </div>
    );
  }

  return (
    <div>
      <h1>{BUSINESS_CASE.title}</h1>
      {saved && (
        <div className="callout">
          <p style={{ margin: 0 }}>Ваш результат: <b>{saved.percent}%</b> ({saved.correct}/{saved.total}) от {new Date(saved.date).toLocaleDateString('ru-RU')}.
            Кейс входит в Marketplace Score с весом 15%. Можно пройти заново — засчитывается последний результат.</p>
        </div>
      )}
      <div className="panel">
        <p style={{ whiteSpace: 'pre-line' }}>{BUSINESS_CASE.intro}</p>
        <h3>Этапы кейса</h3>
        {steps.map((s, i) => (
          <div key={i} className="lesson-list-item">
            <span>{i + 1}. {s.title}</span>
            <span className="badge st-none">{s.questions.length} задач</span>
          </div>
        ))}
        <button className="btn" style={{ marginTop: 10 }} onClick={() => { setAcc({ correct: 0, total: 0 }); startStep(0); }}>
          {saved ? 'Пройти кейс заново' : 'Начать бизнес-кейс'}
        </button>{' '}
        <Link className="btn secondary" to="/project">Финальный проект →</Link>
      </div>
    </div>
  );
}
