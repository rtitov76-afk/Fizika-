import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { MODULES } from '../data/courseIndex.js';
import { loadState } from '../services/storage.js';
import { moduleProgress } from '../services/progress.js';
import ProgressBar from '../components/ProgressBar.jsx';
import { LOCKED_MODULES, FULL_STATS } from '../data/lockedContent.js';

export default function CoursePage() {
  const state = useMemo(() => loadState(), []);
  return (
    <div>
      <h1>Программа курса</h1>
      <p style={{ color: 'var(--muted)' }}>
        Демо-версия: открыты 3 модуля из {FULL_STATS.modules} — введение, юнит-экономика и SEO.
        Уроки открыты для свободного просмотра; урок засчитывается после изучения материала и сдачи теста (порог 70%).
        Остальные модули показаны ниже — они доступны в полной версии курса.
      </p>
      {MODULES.map((m) => {
        const mp = moduleProgress(state, m);
        const status = mp.percent === 100 && mp.testPassed ? 'passed'
          : mp.percent === 100 && mp.testScore != null ? 'test_failed'
          : mp.passed > 0 ? 'started' : 'not_started';
        const statusLabel = { passed: '✓ Пройден', test_failed: '✕ Тест модуля не сдан', started: '◔ В процессе', not_started: '○ Не начат' }[status];
        const statusCls = { passed: 'st-passed', test_failed: 'st-failed', started: 'st-started', not_started: 'st-none' }[status];
        return (
          <div className="panel" key={m.id}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'flex-start', flexWrap: 'wrap' }}>
              <div style={{ flex: 1, minWidth: 260 }}>
                <h3 style={{ margin: 0 }}>
                  <Link to={`/module/${m.id}`}>Модуль {m.order}. {m.title}</Link>
                </h3>
                <p style={{ fontSize: '.9rem', color: 'var(--muted)', margin: '4px 0 8px' }}>{m.description}</p>
                <ProgressBar percent={mp.percent} />
                <div style={{ fontSize: '.8rem', color: 'var(--muted)', marginTop: 4 }}>
                  {mp.passed}/{mp.total} уроков{mp.testScore != null ? ` · тест модуля: ${mp.testScore}%` : ''}
                </div>
              </div>
              <span className={'badge ' + statusCls}>{statusLabel}</span>
            </div>
          </div>
        );
      })}

      <div className="panel" style={{ background: '#fffbeb', border: '1px solid #f59e0b' }}>
        <h2 style={{ marginTop: 0 }}>🔓 В полной версии курса</h2>
        <p style={{ color: 'var(--muted)', margin: 0 }}>
          {FULL_STATS.modules} модулей · {FULL_STATS.lessons} урока · {FULL_STATS.questions} вопросов в банках тестов ·
          {' '}{FULL_STATS.trainers} тренажёров-симуляций · бизнес-кейс из 5 этапов · экзамен на 90 вопросов ·
          глоссарий на {FULL_STATS.glossary} терминов · сертификат с уровнем от Junior до Marketplace Expert.
        </p>
      </div>

      {LOCKED_MODULES.map((m) => (
        <div className="panel" key={m.id} style={{ opacity: 0.65 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'flex-start', flexWrap: 'wrap' }}>
            <div style={{ flex: 1, minWidth: 260 }}>
              <h3 style={{ margin: 0 }}>🔒 Модуль {m.order}. {m.title}</h3>
              <p style={{ fontSize: '.9rem', color: 'var(--muted)', margin: '4px 0 0' }}>{m.description}</p>
              <div style={{ fontSize: '.8rem', color: 'var(--muted)', marginTop: 6 }}>{m.lessons} урока · банк {m.questions} вопросов</div>
            </div>
            <span className="badge st-none">Полная версия</span>
          </div>
        </div>
      ))}
    </div>
  );
}
