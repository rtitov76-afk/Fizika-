import React, { useState } from 'react';
import { loadState, updateState } from '../services/storage.js';
import { MODULES } from '../data/courseIndex.js';

const FIELDS = [
  ['overall', 'Общая оценка курса'],
  ['expectations', 'Соответствие ожиданиям'],
  ['practical', 'Применимость на практике'],
  ['difficulty', 'Сбалансированность сложности'],
  ['recommend', 'Готовность рекомендовать']
];

export default function FeedbackPage() {
  const [state, setState] = useState(() => loadState());
  const saved = state.courseFeedback;
  const [v, setV] = useState(saved?.scores || { overall: 8, expectations: 8, practical: 8, difficulty: 7, recommend: 8 });
  const [best, setBest] = useState(saved?.best || '');
  const [improve, setImprove] = useState(saved?.improve || '');

  function save() {
    const s = updateState((st) => {
      st.courseFeedback = { scores: v, best, improve, date: new Date().toISOString() };
    });
    setState(s);
  }

  const moduleFb = MODULES.map((m) => ({ m, fb: state.modules[m.id]?.feedback })).filter((x) => x.fb);

  return (
    <div>
      <h1>Обратная связь по курсу</h1>
      <div className="panel">
        <h3>Итоговая оценка курса</h3>
        {saved && <p className="callout" style={{ padding: '10px 14px' }}>Спасибо! Отзыв сохранён {new Date(saved.date).toLocaleDateString('ru-RU')}. Можно обновить его ниже.</p>}
        {FIELDS.map(([k, label]) => (
          <div className="field" key={k}>
            <label>{label}: <b>{v[k]}</b>/10</label>
            <input type="range" min="1" max="10" value={v[k]} onChange={(e) => setV({ ...v, [k]: Number(e.target.value) })} />
          </div>
        ))}
        <div className="field">
          <label>Что было самым полезным?</label>
          <textarea rows={3} value={best} onChange={(e) => setBest(e.target.value)} placeholder="Модули, инструменты, форматы…" />
        </div>
        <div className="field">
          <label>Что улучшить?</label>
          <textarea rows={3} value={improve} onChange={(e) => setImprove(e.target.value)} placeholder="Чего не хватило, что было лишним…" />
        </div>
        <button className="btn" onClick={save}>{saved ? 'Обновить отзыв' : 'Сохранить отзыв'}</button>
        <p style={{ fontSize: '.8rem', color: 'var(--muted)', marginTop: 8 }}>Отзыв хранится локально вместе с прогрессом (экспортируется в разделе «Настройки»).</p>
      </div>

      <div className="panel">
        <h3>Ваши оценки модулей</h3>
        {moduleFb.length === 0 && <p style={{ color: 'var(--muted)' }}>Вы ещё не оценивали модули. Форма оценки — внизу страницы каждого модуля.</p>}
        {moduleFb.length > 0 && (
          <table className="tbl">
            <thead><tr><th>Модуль</th><th>Полезность</th><th>Понятность</th><th>Практичность</th><th>Сложность</th><th>Примеры</th></tr></thead>
            <tbody>
              {moduleFb.map(({ m, fb }) => (
                <tr key={m.id}>
                  <td>{m.order}. {m.title}</td>
                  <td>{fb.useful}</td><td>{fb.clarity}</td><td>{fb.practical}</td><td>{fb.difficulty}</td><td>{fb.examples}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
