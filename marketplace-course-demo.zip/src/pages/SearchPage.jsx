import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { search, highlight } from '../services/searchIndex.js';

export default function SearchPage() {
  const [q, setQ] = useState('');
  const results = q.trim().length >= 2 ? search(q) : [];
  return (
    <div>
      <h1>Поиск по курсу</h1>
      <input className="searchbox" autoFocus placeholder="Например: ДРР, оборачиваемость, буллиты, Трафареты…"
        value={q} onChange={(e) => setQ(e.target.value)} />
      {q.trim().length >= 2 && (
        <p style={{ color: 'var(--muted)', fontSize: '.9rem' }}>Найдено: {results.length}</p>
      )}
      {results.map((r) => (
        <div className="panel" key={r.key} style={{ padding: '12px 16px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
            <Link to={r.link}><b>{r.title}</b></Link>
            <span className="badge st-none">{r.kind}</span>
          </div>
          {r.text && <p style={{ margin: '6px 0 0', fontSize: '.88rem', color: 'var(--muted)' }}>{highlight(r.text, q)}</p>}
        </div>
      ))}
      {q.trim().length >= 2 && results.length === 0 && (
        <p className="panel">Ничего не найдено. Попробуйте другой запрос или загляните в <Link to="/glossary">глоссарий</Link>.</p>
      )}
    </div>
  );
}
