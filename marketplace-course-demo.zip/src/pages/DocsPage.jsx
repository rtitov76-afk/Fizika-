import React from 'react';
import { DOCS_LINKS, DOCS_UPDATED } from '../data/docsLinks.js';

export default function DocsPage() {
  return (
    <div>
      <h1>Официальные источники</h1>
      <p style={{ color: 'var(--muted)' }}>Тарифы, комиссии и правила площадок меняются регулярно. Курс учит принципам и формулам,
        а точные текущие цифры всегда проверяйте в официальных источниках и личном кабинете.
        Список актуален на {DOCS_UPDATED}.</p>
      {DOCS_LINKS.map((group) => (
        <div className="panel" key={group.title}>
          <h3>{group.title}</h3>
          {group.links.map((l) => (
            <div key={l.url} className="lesson-list-item">
              <div>
                <a href={l.url} target="_blank" rel="noopener noreferrer"><b>{l.name}</b></a>
                <div style={{ fontSize: '.82rem', color: 'var(--muted)' }}>{l.desc}</div>
              </div>
              <span className="badge st-none">↗</span>
            </div>
          ))}
        </div>
      ))}
      <div className="callout">
        <p style={{ margin: 0 }}><b>Правило курса:</b> устойчивые принципы (юнит-экономика, воронка, оборачиваемость) не устаревают;
          конкретные тарифы и алгоритмы — переменные. Всё, что помечено как «Практическая гипотеза рынка», не подтверждено
          площадками официально и требует собственных тестов.</p>
      </div>
    </div>
  );
}
