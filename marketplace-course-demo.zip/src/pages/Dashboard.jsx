import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { loadState } from '../services/storage.js';
import { overallProgress, competencyScores, platformScore, weakTopics, strongTopics, nextRecommendation, finalScore } from '../services/progress.js';
import { LESSON_MAP, MODULE_MAP } from '../data/courseIndex.js';
import { ACHIEVEMENTS } from '../data/achievements.js';
import StatCard from '../components/StatCard.jsx';
import ProgressBar from '../components/ProgressBar.jsx';

function avgOf(scores, ids) {
  const vals = ids.map((i) => scores[i]).filter((v) => v != null);
  return vals.length ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : null;
}

export default function Dashboard() {
  const state = useMemo(() => loadState(), []);
  const op = overallProgress(state);
  const comp = competencyScores(state);
  const ozon = platformScore(state, 'ozon');
  const wb = platformScore(state, 'wb');
  const weak = weakTopics(state).slice(0, 4);
  const strong = strongTopics(state).slice(0, 4);
  const rec = nextRecommendation(state);
  const fs = finalScore(state);
  const last = state.lastLocation ? LESSON_MAP[state.lastLocation.lessonId] : null;
  const recentAttempts = state.activity.filter((a) => a.type === 'quiz' || a.type === 'module_test' || a.type === 'exam').slice(0, 6);
  const unlocked = ACHIEVEMENTS.filter((a) => a.check(state));
  const hour = new Date().getHours();
  const hello = hour < 6 ? 'Доброй ночи' : hour < 12 ? 'Доброе утро' : hour < 18 ? 'Добрый день' : 'Добрый вечер';

  return (
    <div>
      <h1>{hello}{state.profile.name ? ', ' + state.profile.name : ''}! 👋</h1>
      <p style={{ color: 'var(--muted)' }}>Курс «Продажи и продвижение на маркетплейсах Ozon и Wildberries: от запуска до управления прибылью»</p>

      {!state.diagnostic && (
        <div className="callout violet">
          <h4>Начните с входной диагностики</h4>
          <p>25 минут — и приложение определит ваш текущий уровень, сильные и слабые зоны и построит персональный маршрут обучения.</p>
          <Link className="btn" to="/diagnostic">Пройти диагностику</Link>
        </div>
      )}

      <div className="panel">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
          <div>
            <h2 style={{ margin: 0 }}>Продолжить обучение</h2>
            {last ? (
              <p style={{ margin: '4px 0 0' }}>
                Вы остановились на: <b>{MODULE_MAP[last.moduleId]?.title}</b> → {last.title}
              </p>
            ) : (
              <p style={{ margin: '4px 0 0' }}>Вы ещё не начали обучение. Начните с Модуля 0.</p>
            )}
            {rec.type !== 'done' && rec.lessonId && (
              <p style={{ margin: '4px 0 0', fontSize: '.88rem', color: 'var(--muted)' }}>
                Рекомендуем далее: <b>{rec.title}</b> — {rec.reason}
              </p>
            )}
          </div>
          <Link className="btn" to={last ? `/lesson/${last.id}` : rec.lessonId ? `/lesson/${rec.lessonId}` : '/course'}>
            {last ? 'Продолжить →' : 'Начать курс →'}
          </Link>
        </div>
      </div>

      <div className="grid4">
        <StatCard label="Общий прогресс" value={op.percent + '%'} sub={`${op.passed} из ${op.total} уроков`} />
        <StatCard label="Marketplace Score" value={fs.score + '/100'} sub={fs.level} />
        <StatCard label="Ozon Score" value={ozon == null ? '—' : ozon + '/100'} sub="по урокам и тестам Ozon" />
        <StatCard label="Wildberries Score" value={wb == null ? '—' : wb + '/100'} sub="по урокам и тестам WB" />
      </div>

      <div className="panel" style={{ marginTop: 16 }}>
        <h3>Прогресс по ключевым направлениям</h3>
        {[
          ['Юнит-экономика', comp.unit_economics],
          ['Реклама', comp.advertising],
          ['Аналитика', comp.analytics],
          ['Логистика и запасы', avgOf(comp, ['logistics', 'inventory'])],
          ['Контент и SEO', avgOf(comp, ['content', 'seo'])],
          ['Финансы и управление', avgOf(comp, ['finance', 'team', 'category'])]
        ].map(([label, v]) => (
          <div key={label} style={{ marginBottom: 9 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.88rem' }}>
              <span>{label}</span><b>{v == null ? '—' : v + '%'}</b>
            </div>
            <ProgressBar percent={v ?? 0} />
          </div>
        ))}
      </div>

      <div className="grid2">
        <div className="panel">
          <h3>🔁 Повторить сегодня</h3>
          {weak.length === 0 && <p style={{ color: 'var(--muted)' }}>Слабых тем пока не выявлено. Так держать!</p>}
          {weak.map((w) => (
            <div key={w.lessonId} className="lesson-list-item">
              <Link to={`/lesson/${w.lessonId}`}>{w.title}</Link>
              <span className="badge st-failed">{w.score}%</span>
            </div>
          ))}
          {weak.length > 0 && <Link to="/weak" style={{ fontSize: '.85rem' }}>Все слабые темы →</Link>}
        </div>
        <div className="panel">
          <h3>💪 Сильные темы</h3>
          {strong.length === 0 && <p style={{ color: 'var(--muted)' }}>Пройдите тесты, чтобы увидеть свои сильные стороны.</p>}
          {strong.map((s) => (
            <div key={s.lessonId} className="lesson-list-item">
              <Link to={`/lesson/${s.lessonId}`}>{s.title}</Link>
              <span className="badge st-passed">{s.score}%</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid2">
        <div className="panel">
          <h3>Последние тесты</h3>
          {recentAttempts.length === 0 && <p style={{ color: 'var(--muted)' }}>Пока нет пройденных тестов.</p>}
          {recentAttempts.map((a, i) => (
            <div key={i} className="lesson-list-item">
              <span style={{ fontSize: '.9rem' }}>{a.label}</span>
              <span className={'badge ' + (a.value >= 70 ? 'st-passed' : 'st-failed')}>{a.value}%</span>
            </div>
          ))}
          <Link to="/results" style={{ fontSize: '.85rem' }}>Вся история →</Link>
        </div>
        <div className="panel">
          <h3>🏅 Достижения</h3>
          {unlocked.length === 0 && <p style={{ color: 'var(--muted)' }}>Первое достижение — за первый пройденный модуль.</p>}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {unlocked.map((a) => (
              <span key={a.id} className="badge st-passed" title={a.desc}>{a.icon} {a.title}</span>
            ))}
          </div>
          <Link to="/analytics" style={{ fontSize: '.85rem' }}>Моя аналитика →</Link>
        </div>
      </div>
    </div>
  );
}
