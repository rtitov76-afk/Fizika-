import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { TRAINER_MAP } from '../data/trainers.js';
import { updateState, logActivity } from '../services/storage.js';

export default function TrainerRunPage() {
  const { trainerId } = useParams();
  const t = TRAINER_MAP[trainerId];
  const [step, setStep] = useState(0);
  const [picks, setPicks] = useState([]); // {optIdx, score, feedback}
  const [showFb, setShowFb] = useState(false);
  const [finished, setFinished] = useState(false);
  if (!t) return <div className="panel">Тренажёр не найден. <Link to="/trainers">К списку</Link></div>;

  const cur = t.steps[step];
  const maxScore = t.steps.reduce((a, s) => a + Math.max(...s.options.map((o) => o.score)), 0);
  const gotScore = picks.reduce((a, p) => a + p.score, 0);

  function pick(i) {
    if (showFb) return;
    const opt = cur.options[i];
    setPicks([...picks, { optIdx: i, score: opt.score, feedback: opt.feedback }]);
    setShowFb(true);
  }

  function next() {
    setShowFb(false);
    if (step + 1 < t.steps.length) { setStep(step + 1); return; }
    const percent = Math.round(gotScore / maxScore * 100);
    updateState((st) => {
      st.trainers = st.trainers || {};
      const rec = st.trainers[t.id] || { attempts: 0, bestScore: null, completed: false };
      rec.attempts += 1;
      rec.completed = true;
      if (rec.bestScore == null || percent > rec.bestScore) rec.bestScore = percent;
      st.trainers[t.id] = rec;
    });
    logActivity('trainer', `Тренажёр: ${t.title}`, percent);
    setFinished(true);
  }

  function restart() {
    setStep(0); setPicks([]); setShowFb(false); setFinished(false);
  }

  if (finished) {
    const percent = Math.round(gotScore / maxScore * 100);
    return (
      <div>
        <p><Link to="/trainers">← Все тренажёры</Link></p>
        <h1>{t.icon} {t.title} — результат</h1>
        <div className="panel">
          <h2 style={{ marginTop: 0 }}>Ваш результат: {gotScore} из {maxScore} баллов ({percent}%)</h2>
          <span className={'badge ' + (percent >= 85 ? 'st-passed' : percent >= 60 ? 'st-started' : 'st-failed')}>
            {percent >= 85 ? 'Отличные решения' : percent >= 60 ? 'Хороший уровень, есть что улучшить' : 'Стоит разобрать тему глубже'}
          </span>
          <h3>Разбор сценария</h3>
          <p style={{ whiteSpace: 'pre-line' }}>{t.debrief}</p>
          {t.lessonId && <p><Link to={`/lesson/${t.lessonId}`}>→ Урок по этой теме</Link></p>}
          <button className="btn" onClick={restart}>Пройти заново</button>{' '}
          <Link className="btn secondary" to="/trainers">К списку тренажёров</Link>
        </div>
      </div>
    );
  }

  const picked = showFb ? picks[picks.length - 1] : null;
  return (
    <div>
      <p><Link to="/trainers">← Все тренажёры</Link></p>
      <h1>{t.icon} {t.title}</h1>
      <div className="panel">
        <p style={{ fontSize: '.85rem', color: 'var(--muted)' }}>Шаг {step + 1} из {t.steps.length} · набрано {gotScore} баллов</p>
        <p style={{ whiteSpace: 'pre-line' }}><b>{cur.situation}</b></p>
        {cur.options.map((o, i) => {
          let cls = 'quiz-opt';
          if (showFb) {
            const bestScore = Math.max(...cur.options.map((x) => x.score));
            if (i === picked.optIdx) cls += o.score === bestScore ? ' correct' : ' wrongsel';
            else if (o.score === bestScore) cls += ' correct';
          }
          return (
            <div key={i} className={cls} onClick={() => pick(i)} role="button" tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && pick(i)}>
              {o.text}
            </div>
          );
        })}
        {showFb && (
          <div className="callout" style={{ marginTop: 12 }}>
            <p style={{ margin: 0 }}><b>+{picked.score} баллов.</b> {picked.feedback}</p>
          </div>
        )}
        {showFb && <button className="btn" style={{ marginTop: 12 }} onClick={next}>
          {step + 1 < t.steps.length ? 'Следующий шаг →' : 'Завершить сценарий'}
        </button>}
      </div>
    </div>
  );
}
