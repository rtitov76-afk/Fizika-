import React, { useEffect, useMemo, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { LESSON_MAP, MODULE_MAP, ALL_LESSONS } from '../data/courseIndex.js';
import { loadState, updateState, logActivity } from '../services/storage.js';
import { lessonStatus, STATUS_META } from '../services/progress.js';
import { sampleQuestions } from '../services/quiz.js';
import QuizRunner from '../components/QuizRunner.jsx';

const SECTION_TITLES = {
  learn: '🎯 Что вы узнаете', why: '❗ Почему это важно', theory: 'Теория', terms: '📖 Термины',
  formula: '🧮 Формула', example: '💡 Пример', calcExample: '🔢 Практический расчёт', case: '💼 Бизнес-кейс',
  mistakes: '⚠️ Типичные ошибки', tips: '✅ Практические рекомендации', practice: '✍️ Практическое задание',
  summary: '📌 Ключевые выводы', table: 'Таблица', list: ''
};

export default function LessonPage() {
  const { lessonId } = useParams();
  const lesson = LESSON_MAP[lessonId];
  const [state, setState] = useState(() => loadState());
  const [tab, setTab] = useState('material');
  const [quizQs, setQuizQs] = useState(null);
  const [note, setNote] = useState('');
  const [practiceAnswer, setPracticeAnswer] = useState('');

  useEffect(() => {
    if (!lesson) return;
    setTab('material'); setQuizQs(null);
    const s = updateState((st) => {
      st.lessons[lesson.id] = st.lessons[lesson.id] || { status: 'started', attempts: [], bestScore: null, studiedAt: null };
      st.lastLocation = { moduleId: lesson.moduleId, lessonId: lesson.id };
    });
    setState(s);
    setNote(s.notes[lesson.id]?.text || '');
    setPracticeAnswer(s.practice[lesson.id]?.answer || '');
    window.scrollTo(0, 0);
  }, [lessonId]); // eslint-disable-line

  const mod = lesson ? MODULE_MAP[lesson.moduleId] : null;
  const idx = useMemo(() => ALL_LESSONS.findIndex((l) => l.id === lessonId), [lessonId]);
  const prev = idx > 0 ? ALL_LESSONS[idx - 1] : null;
  const next = idx >= 0 && idx < ALL_LESSONS.length - 1 ? ALL_LESSONS[idx + 1] : null;

  if (!lesson) return <div className="panel">Урок не найден. <Link to="/course">К программе курса</Link></div>;

  const rec = state.lessons[lesson.id] || {};
  const status = lessonStatus(state, lesson);
  const meta = STATUS_META[status];
  const bookmarked = state.bookmarks.includes(lesson.id);
  const practiceDone = !!state.practice[lesson.id]?.done;

  function markStudied() {
    const s = updateState((st) => { st.lessons[lesson.id].studiedAt = new Date().toISOString(); });
    setState(s);
    logActivity('study', `Изучен материал: ${lesson.title}`);
  }

  function toggleBookmark() {
    const s = updateState((st) => {
      st.bookmarks = st.bookmarks.includes(lesson.id)
        ? st.bookmarks.filter((x) => x !== lesson.id)
        : [...st.bookmarks, lesson.id];
    });
    setState(s);
  }

  function saveNote() {
    const s = updateState((st) => {
      if (note.trim()) st.notes[lesson.id] = { text: note.trim(), updatedAt: new Date().toISOString() };
      else delete st.notes[lesson.id];
    });
    setState(s);
  }

  function savePractice() {
    const s = updateState((st) => {
      st.practice[lesson.id] = { done: true, answer: practiceAnswer.trim(), date: new Date().toISOString() };
    });
    setState(s);
    logActivity('practice', `Выполнено задание: ${lesson.title}`);
  }

  function startQuiz() {
    if (!rec.studiedAt) markStudied();
    setQuizQs(sampleQuestions(lesson.quiz.bank, lesson.quiz.show ?? 6));
    setTab('quiz');
  }

  function onQuizFinish(res) {
    const s = updateState((st) => {
      const r = st.lessons[lesson.id];
      r.attempts.push({ date: res.date, score: res.percent, correct: res.correct, total: res.total, timeSec: res.timeSec, wrong: res.wrong });
      r.bestScore = Math.max(r.bestScore ?? 0, res.percent);
    });
    setState(s);
    logActivity('quiz', `Тест урока: ${lesson.title}`, res.percent);
  }

  return (
    <div>
      <p>
        <Link to={`/module/${mod.id}`}>← Модуль {mod.order}. {mod.title}</Link>
      </p>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap', alignItems: 'flex-start' }}>
        <h1 style={{ marginBottom: 4 }}>{lesson.title}</h1>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span className={'badge ' + meta.cls}>{meta.icon} {meta.label}</span>
          <button className="btn small secondary" onClick={toggleBookmark} aria-pressed={bookmarked}>
            {bookmarked ? '⭐ В избранном' : '☆ В избранное'}
          </button>
        </div>
      </div>
      {rec.bestScore != null && <p style={{ color: 'var(--muted)', fontSize: '.88rem' }}>Лучший результат теста: <b>{rec.bestScore}%</b> · попыток: {rec.attempts.length}</p>}

      <div style={{ display: 'flex', gap: 8, margin: '14px 0' }} className="no-print">
        <button className={'btn small' + (tab === 'material' ? '' : ' secondary')} onClick={() => setTab('material')}>📄 Материал</button>
        <button className={'btn small' + (tab === 'quiz' ? '' : ' secondary')} onClick={() => (quizQs ? setTab('quiz') : startQuiz())}>🧪 Проверка знаний</button>
        <button className={'btn small' + (tab === 'notes' ? '' : ' secondary')} onClick={() => setTab('notes')}>📝 Заметка</button>
      </div>

      {tab === 'material' && (
        <div>
          {lesson.sections.map((s, i) => <Section key={i} s={s} />)}
          {lesson.actuality && (
            <div className="actuality">ℹ️ Актуальность информации о тарифах и правилах площадок: {lesson.actuality}. Точные значения проверяйте в личных кабинетах seller.ozon.ru и seller.wildberries.ru — площадки меняют условия несколько раз в год.</div>
          )}
          <div className="panel" style={{ marginTop: 18 }}>
            <h3>Практическое задание</h3>
            {lesson.sections.filter((s) => s.type === 'practice').length === 0 && <p style={{ color: 'var(--muted)' }}>Задание приведено в тексте урока выше.</p>}
            <div className="field">
              <label>Ваш ответ / результат выполнения (сохранится в приложении)</label>
              <textarea value={practiceAnswer} onChange={(e) => setPracticeAnswer(e.target.value)} placeholder="Опишите, что вы сделали и к какому выводу пришли…" />
            </div>
            <button className="btn small" onClick={savePractice} disabled={!practiceAnswer.trim()}>
              {practiceDone ? '✓ Обновить выполнение' : 'Отметить задание выполненным'}
            </button>
            {practiceDone && <span style={{ marginLeft: 10, color: 'var(--green)', fontSize: '.88rem' }}>✓ Задание засчитано</span>}
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 14, flexWrap: 'wrap' }}>
            {!rec.studiedAt && <button className="btn secondary" onClick={markStudied}>Материал изучен ✓</button>}
            <button className="btn" onClick={startQuiz}>Перейти к проверке знаний →</button>
          </div>
        </div>
      )}

      {tab === 'quiz' && quizQs && (
        <div>
          <p style={{ color: 'var(--muted)', fontSize: '.9rem' }}>
            {quizQs.length} вопросов случайной выборкой из банка ({lesson.quiz.bank.length}). Порог — {lesson.quiz.pass ?? 70}%. При повторной попытке вопросы будут другими.
          </p>
          <QuizRunner key={quizQs.map((q) => q.id).join()} questions={quizQs} pass={lesson.quiz.pass ?? 70} title={`Тест: ${lesson.title}`} onFinish={onQuizFinish} />
          <div style={{ marginTop: 14, display: 'flex', gap: 10 }}>
            <button className="btn secondary" onClick={startQuiz}>Пройти ещё раз (новые вопросы)</button>
          </div>
        </div>
      )}

      {tab === 'notes' && (
        <div className="panel">
          <h3>Моя заметка к уроку</h3>
          <div className="field">
            <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Ваши мысли, инсайты, план действий…" style={{ minHeight: 160 }} />
          </div>
          <button className="btn small" onClick={saveNote}>Сохранить заметку</button>
          <Link to="/notes" style={{ marginLeft: 12, fontSize: '.88rem' }}>Все мои заметки →</Link>
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 26 }} className="no-print">
        {prev ? <Link to={`/lesson/${prev.id}`}>← {prev.title}</Link> : <span />}
        {next ? <Link to={`/lesson/${next.id}`}>{next.title} →</Link> : <span />}
      </div>
    </div>
  );
}

function Section({ s }) {
  const title = s.title || SECTION_TITLES[s.type];
  switch (s.type) {
    case 'learn':
    case 'summary':
    case 'mistakes':
    case 'tips':
      return (
        <div className={'callout ' + (s.type === 'mistakes' ? 'red' : s.type === 'tips' ? 'green' : s.type === 'summary' ? 'violet' : '')}>
          <h4>{title}</h4>
          <ul style={{ margin: '4px 0', paddingLeft: 20 }}>
            {s.items.map((it, i) => <li key={i}>{it}</li>)}
          </ul>
        </div>
      );
    case 'why':
      return <div className="callout amber"><h4>{title}</h4><p style={{ margin: 0 }}>{s.text}</p></div>;
    case 'theory':
      return (
        <div className="lesson-section">
          {s.title && <h2>{s.title}</h2>}
          {String(s.text).split('\n\n').map((p, i) => <p key={i}>{p}</p>)}
        </div>
      );
    case 'terms':
      return (
        <div className="lesson-section">
          <h3>{title}</h3>
          <table className="tbl"><tbody>
            {s.items.map((t, i) => <tr key={i}><td style={{ width: '30%' }}><b>{t.term}</b></td><td>{t.def}</td></tr>)}
          </tbody></table>
        </div>
      );
    case 'formula':
      return (
        <div className="lesson-section">
          <h3>🧮 {s.title || 'Формула'}</h3>
          <div className="formula-box">{s.formula}</div>
          {s.legend && <div className="formula-legend">{s.legend}</div>}
        </div>
      );
    case 'example':
    case 'calcExample':
    case 'case':
    case 'practice':
      return (
        <div className="panel" style={{ background: s.type === 'case' ? '#fbfaff' : undefined }}>
          <h3 style={{ marginTop: 0 }}>{SECTION_TITLES[s.type]}{s.title ? ': ' + s.title : ''}</h3>
          {String(s.text).split('\n\n').map((p, i) => <p key={i} style={{ whiteSpace: 'pre-wrap' }}>{p}</p>)}
        </div>
      );
    case 'ozon':
      return <div className="platform-note ozon"><h4>🔵 Как это выглядит на Ozon</h4>{String(s.text).split('\n\n').map((p, i) => <p key={i}>{p}</p>)}</div>;
    case 'wb':
      return <div className="platform-note wb"><h4>🟣 Как это выглядит на Wildberries</h4>{String(s.text).split('\n\n').map((p, i) => <p key={i}>{p}</p>)}</div>;
    case 'table':
      return (
        <div className="lesson-section">
          {s.title && <h3>{s.title}</h3>}
          <table className="tbl">
            <thead><tr>{s.head.map((h, i) => <th key={i}>{h}</th>)}</tr></thead>
            <tbody>{s.rows.map((r, i) => <tr key={i}>{r.map((c, j) => <td key={j}>{c}</td>)}</tr>)}</tbody>
          </table>
        </div>
      );
    case 'videos':
      return (
        <div className="panel">
          <h3 style={{ marginTop: 0 }}>🎬 Дополнительные видео</h3>
          <p style={{ fontSize: '.88rem', color: 'var(--muted)' }}>Подобранные поисковые запросы — откроются в YouTube с актуальной выдачей (прямые ссылки быстро устаревают):</p>
          {s.queries.map((q, i) => (
            <a key={i} className="btn small secondary" style={{ margin: '4px 6px 4px 0' }} target="_blank" rel="noreferrer"
               href={'https://www.youtube.com/results?search_query=' + encodeURIComponent(q)}>▶ {q}</a>
          ))}
        </div>
      );
    default:
      return null;
  }
}
