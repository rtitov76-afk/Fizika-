import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { loadState } from '../services/storage.js';
import { weakTopics } from '../services/progress.js';
import { LESSON_MAP, MODULE_MAP } from '../data/courseIndex.js';

export default function WeakTopicsPage() {
  const state = useMemo(() => loadState(), []);
  const weak = weakTopics(state);
  return (
    <div>
      <h1>Нужно повторить</h1>
      <p style={{ color: 'var(--muted)' }}>Темы, где лучший результат ниже 70% или где вы стабильно ошибаетесь в одних и тех же вопросах.
        Перепройдите урок и сдайте тест заново — при результате ≥70% тема исчезнет из списка.</p>
      {weak.length === 0 && (
        <div className="callout"><p style={{ margin: 0 }}>🎉 Слабых тем не выявлено. Продолжайте проходить модули — список обновляется автоматически.</p></div>
      )}
      {weak.map((w) => {
        const l = LESSON_MAP[w.lessonId];
        return (
          <div className="panel" key={w.lessonId}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
              <div>
                <Link to={`/lesson/${w.lessonId}`}><b>{w.title}</b></Link>
                <div style={{ fontSize: '.8rem', color: 'var(--muted)' }}>{l ? MODULE_MAP[l.moduleId]?.title : ''}</div>
                <div style={{ fontSize: '.85rem', marginTop: 4, color: 'var(--muted)' }}>
                  {w.reason === 'topics'
                    ? 'Повторяющиеся ошибки по темам: ' + (w.topics || []).join(', ')
                    : 'Результат ниже порога 70%'}
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <span className="badge st-failed">{w.score != null ? w.score + '%' : 'не сдано'}</span>
                <div><Link className="btn small" style={{ marginTop: 6 }} to={`/lesson/${w.lessonId}`}>Повторить →</Link></div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
