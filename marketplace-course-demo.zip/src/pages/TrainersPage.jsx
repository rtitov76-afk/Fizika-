import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { TRAINERS } from '../data/trainers.js';
import { loadState } from '../services/storage.js';
import { LOCKED_TRAINERS } from '../data/lockedContent.js';

export default function TrainersPage() {
  const state = useMemo(() => loadState(), []);
  return (
    <div>
      <h1>Тренажёры-сценарии</h1>
      <p style={{ color: 'var(--muted)' }}>Практика принятия решений в реальных ситуациях селлера. В каждом сценарии вы
        проходите цепочку решений, а в конце получаете разбор: что было оптимально и почему.</p>
      {TRAINERS.map((t) => {
        const best = state.trainers?.[t.id]?.bestScore;
        const done = state.trainers?.[t.id]?.completed;
        return (
          <div className="panel" key={t.id}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'flex-start', flexWrap: 'wrap' }}>
              <div style={{ flex: 1, minWidth: 260 }}>
                <h3 style={{ margin: 0 }}>{t.icon} {t.title}</h3>
                <p style={{ fontSize: '.9rem', color: 'var(--muted)', margin: '4px 0 8px' }}>{t.desc}</p>
                <Link className="btn small" to={`/trainers/${t.id}`}>{done ? 'Пройти ещё раз' : 'Начать сценарий'}</Link>
              </div>
              {done && <span className={'badge ' + (best >= 70 ? 'st-passed' : 'st-started')}>{best}% лучший</span>}
            </div>
          </div>
        );
      })}

      <h2>🔒 Ещё 7 сценариев — в полной версии</h2>
      {LOCKED_TRAINERS.map((t) => (
        <div className="panel" key={t.id} style={{ opacity: 0.65 }}>
          <h3 style={{ margin: 0 }}>{t.icon} {t.title}</h3>
          <p style={{ fontSize: '.9rem', color: 'var(--muted)', margin: '4px 0 0' }}>{t.desc}</p>
        </div>
      ))}
    </div>
  );
}
