import React, { useState } from 'react';

const fmt = (n, d = 0) => (isFinite(n) ? n.toLocaleString('ru-RU', { maximumFractionDigits: d, minimumFractionDigits: 0 }) : '—');
const pct = (n, d = 1) => (isFinite(n) ? n.toLocaleString('ru-RU', { maximumFractionDigits: d }) + '%' : '—');

function Num({ label, value, onChange, step = 1, suffix }) {
  return (
    <div className="field">
      <label>{label}{suffix ? ` (${suffix})` : ''}</label>
      <input type="number" value={value} step={step} onChange={(e) => onChange(Number(e.target.value))} />
    </div>
  );
}

function Calc({ title, desc, children }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="panel">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }} onClick={() => setOpen(!open)}>
        <div>
          <h3 style={{ margin: 0 }}>{title}</h3>
          <p style={{ margin: '4px 0 0', fontSize: '.88rem', color: 'var(--muted)' }}>{desc}</p>
        </div>
        <span className="badge st-none">{open ? '▲ Свернуть' : '▼ Открыть'}</span>
      </div>
      {open && <div style={{ marginTop: 12 }}>{children}</div>}
    </div>
  );
}

function Result({ rows, note }) {
  return (
    <div className="calc-result">
      {rows.map(([label, value, cls]) => (
        <div key={label} style={{ display: 'flex', justifyContent: 'space-between', padding: '3px 0' }}>
          <span>{label}</span><b className={cls || ''}>{value}</b>
        </div>
      ))}
      {note && <p style={{ fontSize: '.8rem', color: 'var(--muted)', marginTop: 8, marginBottom: 0 }}>{note}</p>}
    </div>
  );
}

/* 1. Юнит-экономика */
function UnitEconomics() {
  const [v, setV] = useState({ price: 1500, buyPrice: 500, commission: 18, logistics: 90, returns: 8, returnCost: 50, storage: 15, acquiring: 1.5, ads: 150, tax: 6, other: 20 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const commissionRub = v.price * v.commission / 100;
  const acquiringRub = v.price * v.acquiring / 100;
  const returnLoss = (v.logistics + v.returnCost) * (v.returns / 100 / (1 - v.returns / 100));
  const taxRub = v.price * v.tax / 100;
  const totalCosts = v.buyPrice + commissionRub + v.logistics + returnLoss + v.storage + acquiringRub + v.ads + taxRub + v.other;
  const profit = v.price - totalCosts;
  const margin = profit / v.price * 100;
  const roi = v.buyPrice > 0 ? profit / v.buyPrice * 100 : 0;
  return (
    <>
      <div className="calc-grid">
        <Num label="Цена продажи" value={v.price} onChange={set('price')} suffix="₽" step={50} />
        <Num label="Закупочная цена" value={v.buyPrice} onChange={set('buyPrice')} suffix="₽" step={50} />
        <Num label="Комиссия площадки" value={v.commission} onChange={set('commission')} suffix="%" step={0.5} />
        <Num label="Логистика до клиента" value={v.logistics} onChange={set('logistics')} suffix="₽" step={10} />
        <Num label="Процент выкупа: невыкуп" value={v.returns} onChange={set('returns')} suffix="%" step={1} />
        <Num label="Обратная логистика возврата" value={v.returnCost} onChange={set('returnCost')} suffix="₽" step={10} />
        <Num label="Хранение (на 1 продажу)" value={v.storage} onChange={set('storage')} suffix="₽" step={5} />
        <Num label="Эквайринг" value={v.acquiring} onChange={set('acquiring')} suffix="%" step={0.1} />
        <Num label="Реклама (на 1 продажу)" value={v.ads} onChange={set('ads')} suffix="₽" step={10} />
        <Num label="Налог (от оборота)" value={v.tax} onChange={set('tax')} suffix="%" step={1} />
        <Num label="Прочее (упаковка и др.)" value={v.other} onChange={set('other')} suffix="₽" step={5} />
      </div>
      <Result rows={[
        ['Комиссия', fmt(commissionRub) + ' ₽'],
        ['Потери на невыкупах (на 1 продажу)', fmt(returnLoss) + ' ₽'],
        ['Все затраты на единицу', fmt(totalCosts) + ' ₽'],
        ['Прибыль с единицы', fmt(profit) + ' ₽', profit >= 0 ? 'ok' : 'bad'],
        ['Маржинальность', pct(margin), margin >= 15 ? 'ok' : 'bad'],
        ['ROI на закупку', pct(roi)]
      ]} note="Ориентир здоровой юнит-экономики: маржинальность от 15–20% после всех расходов, включая рекламу и налог." />
    </>
  );
}

/* 2. Минимальная цена */
function MinPrice() {
  const [v, setV] = useState({ buyPrice: 500, commission: 18, logistics: 90, otherFix: 85, tax: 6, acquiring: 1.5, targetMargin: 15 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const varPct = (v.commission + v.tax + v.acquiring + v.targetMargin) / 100;
  const fix = v.buyPrice + v.logistics + v.otherFix;
  const minPrice = varPct < 1 ? fix / (1 - varPct) : NaN;
  const breakEven = (v.commission + v.tax + v.acquiring) / 100 < 1 ? fix / (1 - (v.commission + v.tax + v.acquiring) / 100) : NaN;
  return (
    <>
      <div className="calc-grid">
        <Num label="Закупочная цена" value={v.buyPrice} onChange={set('buyPrice')} suffix="₽" step={50} />
        <Num label="Комиссия" value={v.commission} onChange={set('commission')} suffix="%" step={0.5} />
        <Num label="Логистика (с учётом невыкупов)" value={v.logistics} onChange={set('logistics')} suffix="₽" step={10} />
        <Num label="Прочие фикс. затраты (хранение, упаковка, реклама)" value={v.otherFix} onChange={set('otherFix')} suffix="₽" step={5} />
        <Num label="Налог" value={v.tax} onChange={set('tax')} suffix="%" step={1} />
        <Num label="Эквайринг" value={v.acquiring} onChange={set('acquiring')} suffix="%" step={0.1} />
        <Num label="Целевая маржа" value={v.targetMargin} onChange={set('targetMargin')} suffix="%" step={1} />
      </div>
      <Result rows={[
        ['Точка безубыточности (цена)', fmt(breakEven) + ' ₽'],
        ['Минимальная цена с целевой маржой', fmt(minPrice) + ' ₽', 'ok']
      ]} note="Формула: Цена = Фикс. затраты / (1 − доля процентных затрат − целевая маржа). Ниже точки безубыточности каждая продажа приносит убыток." />
    </>
  );
}

/* 3. Скидка и акция */
function PromoCalc() {
  const [v, setV] = useState({ price: 1500, unitCost: 1100, discount: 15, upliftPct: 60, baseSales: 100 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const newPrice = v.price * (1 - v.discount / 100);
  const profitBefore = (v.price - v.unitCost) * v.baseSales;
  const varPart = v.unitCost * 0.35; // примерная доля затрат, зависящих от цены
  const newUnitCost = v.unitCost - (v.price - newPrice) * 0.22; // комиссия+налог ~22% от снижения цены
  const newSales = v.baseSales * (1 + v.upliftPct / 100);
  const profitAfter = (newPrice - newUnitCost) * newSales;
  const needUplift = (v.price - v.unitCost) > 0 && (newPrice - newUnitCost) > 0
    ? ((v.price - v.unitCost) / (newPrice - newUnitCost) - 1) * 100 : NaN;
  return (
    <>
      <div className="calc-grid">
        <Num label="Текущая цена" value={v.price} onChange={set('price')} suffix="₽" step={50} />
        <Num label="Затраты на единицу (при текущей цене)" value={v.unitCost} onChange={set('unitCost')} suffix="₽" step={50} />
        <Num label="Скидка в акции" value={v.discount} onChange={set('discount')} suffix="%" step={1} />
        <Num label="Ожидаемый прирост продаж" value={v.upliftPct} onChange={set('upliftPct')} suffix="%" step={5} />
        <Num label="Базовые продажи (шт/мес)" value={v.baseSales} onChange={set('baseSales')} step={10} />
      </div>
      <Result rows={[
        ['Цена в акции', fmt(newPrice) + ' ₽'],
        ['Прибыль без акции', fmt(profitBefore) + ' ₽'],
        ['Прибыль в акции (прогноз)', fmt(profitAfter) + ' ₽', profitAfter >= profitBefore ? 'ok' : 'bad'],
        ['Мин. прирост продаж, чтобы акция окупилась', pct(needUplift)]
      ]} note="Расчёт учитывает, что комиссия и налог снижаются вместе с ценой (≈22% от снижения). Если требуемый прирост больше реально ожидаемого — в акцию входить невыгодно (кроме задач по оборачиваемости и рангу)." />
    </>
  );
}

/* 4. ДРР / ROAS */
function DrrCalc() {
  const [v, setV] = useState({ adSpend: 30000, revenue: 250000, margin: 25 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const drr = v.revenue > 0 ? v.adSpend / v.revenue * 100 : NaN;
  const roas = v.adSpend > 0 ? v.revenue / v.adSpend : NaN;
  const maxDrr = v.margin;
  const adProfit = v.revenue * (v.margin / 100) - v.adSpend;
  return (
    <>
      <div className="calc-grid">
        <Num label="Расходы на рекламу" value={v.adSpend} onChange={set('adSpend')} suffix="₽" step={1000} />
        <Num label="Выручка с рекламы" value={v.revenue} onChange={set('revenue')} suffix="₽" step={5000} />
        <Num label="Маржинальность до рекламы" value={v.margin} onChange={set('margin')} suffix="%" step={1} />
      </div>
      <Result rows={[
        ['ДРР (доля рекламных расходов)', pct(drr), drr <= maxDrr ? 'ok' : 'bad'],
        ['ROAS', isFinite(roas) ? roas.toFixed(2) : '—'],
        ['Предельный ДРР (= маржа)', pct(maxDrr)],
        ['Прибыль с учётом рекламы', fmt(adProfit) + ' ₽', adProfit >= 0 ? 'ok' : 'bad']
      ]} note="ДРР = Расходы на рекламу / Выручка × 100%. Если ДРР выше маржинальности — реклама сжигает прибыль (допустимо осознанно только на этапе запуска)." />
    </>
  );
}

/* 5. Оборачиваемость и запасы */
function StockCalc() {
  const [v, setV] = useState({ stock: 600, salesPerDay: 12, leadTimeDays: 20, safetyDays: 7 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const daysLeft = v.salesPerDay > 0 ? v.stock / v.salesPerDay : NaN;
  const reorderPoint = v.salesPerDay * (v.leadTimeDays + v.safetyDays);
  const orderNow = v.stock <= reorderPoint;
  const turnover = daysLeft;
  return (
    <>
      <div className="calc-grid">
        <Num label="Остаток на складе" value={v.stock} onChange={set('stock')} suffix="шт" step={10} />
        <Num label="Средние продажи в день" value={v.salesPerDay} onChange={set('salesPerDay')} suffix="шт" step={1} />
        <Num label="Срок поставки (производство + логистика)" value={v.leadTimeDays} onChange={set('leadTimeDays')} suffix="дней" step={1} />
        <Num label="Страховой запас" value={v.safetyDays} onChange={set('safetyDays')} suffix="дней" step={1} />
      </div>
      <Result rows={[
        ['Запаса хватит на', fmt(daysLeft) + ' дней', daysLeft >= v.leadTimeDays + v.safetyDays ? 'ok' : 'bad'],
        ['Оборачиваемость', fmt(turnover) + ' дней'],
        ['Точка заказа (Reorder Point)', fmt(reorderPoint) + ' шт'],
        ['Заказывать сейчас?', orderNow ? 'ДА — пора размещать заказ' : 'Пока нет', orderNow ? 'bad' : 'ok']
      ]} note="Точка заказа = Продажи в день × (Срок поставки + Страховой запас). Out-of-stock обнуляет позиции в поиске — дороже, чем лишние 1–2 недели хранения." />
    </>
  );
}

/* 6. Объём поставки */
function SupplyCalc() {
  const [v, setV] = useState({ salesPerDay: 12, periodDays: 45, growthPct: 20, stock: 300, inTransit: 0 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const need = v.salesPerDay * (1 + v.growthPct / 100) * v.periodDays - v.stock - v.inTransit;
  return (
    <>
      <div className="calc-grid">
        <Num label="Средние продажи в день" value={v.salesPerDay} onChange={set('salesPerDay')} suffix="шт" step={1} />
        <Num label="На сколько дней поставка" value={v.periodDays} onChange={set('periodDays')} suffix="дней" step={5} />
        <Num label="Ожидаемый рост продаж" value={v.growthPct} onChange={set('growthPct')} suffix="%" step={5} />
        <Num label="Текущий остаток" value={v.stock} onChange={set('stock')} suffix="шт" step={10} />
        <Num label="Уже в пути" value={v.inTransit} onChange={set('inTransit')} suffix="шт" step={10} />
      </div>
      <Result rows={[
        ['Объём поставки', fmt(Math.max(0, need)) + ' шт', 'ok']
      ]} note="Поставка = Продажи в день × Коэффициент роста × Период − Остаток − В пути. Для сезонных товаров вместо среднего берите прогноз по прошлогодней динамике." />
    </>
  );
}

/* 7. Процент выкупа и его цена */
function BuyoutCalc() {
  const [v, setV] = useState({ orders: 100, buyoutPct: 75, logistics: 90, backLogistics: 50 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const buyouts = v.orders * v.buyoutPct / 100;
  const returns = v.orders - buyouts;
  const returnCosts = returns * (v.logistics + v.backLogistics);
  const perSale = buyouts > 0 ? returnCosts / buyouts : NaN;
  return (
    <>
      <div className="calc-grid">
        <Num label="Заказов за период" value={v.orders} onChange={set('orders')} suffix="шт" step={10} />
        <Num label="Процент выкупа" value={v.buyoutPct} onChange={set('buyoutPct')} suffix="%" step={1} />
        <Num label="Логистика к клиенту" value={v.logistics} onChange={set('logistics')} suffix="₽" step={10} />
        <Num label="Обратная логистика" value={v.backLogistics} onChange={set('backLogistics')} suffix="₽" step={10} />
      </div>
      <Result rows={[
        ['Выкупов', fmt(buyouts) + ' шт'],
        ['Возвратов', fmt(returns) + ' шт'],
        ['Затраты на возвраты за период', fmt(returnCosts) + ' ₽', 'bad'],
        ['Надбавка к себестоимости каждой продажи', fmt(perSale) + ' ₽']
      ]} note="В одежде и обуви выкуп 20–50% — потери на возвратной логистике обязаны быть заложены в цену. Повышение выкупа на 5 п.п. часто даёт больше прибыли, чем рост продаж на 10%." />
    </>
  );
}

/* 8. Воронка продаж */
function FunnelCalc() {
  const [v, setV] = useState({ impressions: 100000, ctr: 3, cartRate: 25, orderRate: 40, buyoutPct: 90, price: 1500 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const clicks = v.impressions * v.ctr / 100;
  const carts = clicks * v.cartRate / 100;
  const orders = carts * v.orderRate / 100;
  const buyouts = orders * v.buyoutPct / 100;
  const revenue = buyouts * v.price;
  const cr = clicks > 0 ? orders / clicks * 100 : NaN;
  return (
    <>
      <div className="calc-grid">
        <Num label="Показы" value={v.impressions} onChange={set('impressions')} step={5000} />
        <Num label="CTR (клики из показов)" value={v.ctr} onChange={set('ctr')} suffix="%" step={0.1} />
        <Num label="Конверсия в корзину" value={v.cartRate} onChange={set('cartRate')} suffix="%" step={1} />
        <Num label="Конверсия корзины в заказ" value={v.orderRate} onChange={set('orderRate')} suffix="%" step={1} />
        <Num label="Процент выкупа" value={v.buyoutPct} onChange={set('buyoutPct')} suffix="%" step={1} />
        <Num label="Средняя цена" value={v.price} onChange={set('price')} suffix="₽" step={50} />
      </div>
      <div className="calc-result">
        {[['Показы', v.impressions], ['Клики', clicks], ['Корзины', carts], ['Заказы', orders], ['Выкупы', buyouts]].map(([label, val], i, arr) => (
          <div key={label} style={{ marginBottom: 6 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.88rem' }}>
              <span>{label}</span><b>{fmt(val)}</b>
            </div>
            <div className="funnel-bar" style={{ width: Math.max(4, val / arr[0][1] * 100) + '%' }} />
          </div>
        ))}
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 8 }}>
          <span>CR (клик → заказ)</span><b>{pct(cr)}</b>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <span>Выручка (по выкупам)</span><b className="ok">{fmt(revenue)} ₽</b>
        </div>
      </div>
      <p style={{ fontSize: '.8rem', color: 'var(--muted)' }}>Меняйте по одному показателю, чтобы увидеть, какой этап воронки даёт наибольший прирост выручки. Обычно самый дешёвый рост — CTR (главное фото) и конверсия в корзину (цена/отзывы).</p>
    </>
  );
}

/* 9. План по прибыли → декомпозиция */
function DecompCalc() {
  const [v, setV] = useState({ targetProfit: 300000, margin: 18, avgCheck: 1500, buyoutPct: 90, cr: 3, ctr: 3 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const revenue = v.margin > 0 ? v.targetProfit / (v.margin / 100) : NaN;
  const buyouts = v.avgCheck > 0 ? revenue / v.avgCheck : NaN;
  const orders = v.buyoutPct > 0 ? buyouts / (v.buyoutPct / 100) : NaN;
  const clicks = v.cr > 0 ? orders / (v.cr / 100) : NaN;
  const impressions = v.ctr > 0 ? clicks / (v.ctr / 100) : NaN;
  return (
    <>
      <div className="calc-grid">
        <Num label="Целевая прибыль в месяц" value={v.targetProfit} onChange={set('targetProfit')} suffix="₽" step={10000} />
        <Num label="Маржинальность" value={v.margin} onChange={set('margin')} suffix="%" step={1} />
        <Num label="Средний чек" value={v.avgCheck} onChange={set('avgCheck')} suffix="₽" step={50} />
        <Num label="Процент выкупа" value={v.buyoutPct} onChange={set('buyoutPct')} suffix="%" step={1} />
        <Num label="CR (клик → заказ)" value={v.cr} onChange={set('cr')} suffix="%" step={0.1} />
        <Num label="CTR" value={v.ctr} onChange={set('ctr')} suffix="%" step={0.1} />
      </div>
      <Result rows={[
        ['Нужная выручка (по выкупам)', fmt(revenue) + ' ₽'],
        ['Выкупов в месяц', fmt(buyouts) + ' шт'],
        ['Заказов в месяц', fmt(orders) + ' шт'],
        ['Кликов (визитов в карточку)', fmt(clicks)],
        ['Показов', fmt(impressions)]
      ]} note="Декомпозиция сверху вниз: Прибыль → Выручка → Выкупы → Заказы → Клики → Показы. Если нужных показов в нише физически нет — план недостижим без расширения ассортимента или площадок." />
    </>
  );
}

/* 10. Сравнение FBO vs FBS */
function FboFbsCalc() {
  const [v, setV] = useState({ price: 1500, fboLog: 90, fboStorage: 25, fbsLog: 120, fbsOwnCosts: 45, salesPerMonth: 300 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const fboCost = v.fboLog + v.fboStorage;
  const fbsCost = v.fbsLog + v.fbsOwnCosts;
  const diff = (fbsCost - fboCost) * v.salesPerMonth;
  return (
    <>
      <div className="calc-grid">
        <Num label="Цена товара" value={v.price} onChange={set('price')} suffix="₽" step={50} />
        <Num label="FBO: логистика единицы" value={v.fboLog} onChange={set('fboLog')} suffix="₽" step={5} />
        <Num label="FBO: хранение на единицу" value={v.fboStorage} onChange={set('fboStorage')} suffix="₽" step={5} />
        <Num label="FBS: логистика единицы" value={v.fbsLog} onChange={set('fbsLog')} suffix="₽" step={5} />
        <Num label="FBS: свой склад+сборка на единицу" value={v.fbsOwnCosts} onChange={set('fbsOwnCosts')} suffix="₽" step={5} />
        <Num label="Продаж в месяц" value={v.salesPerMonth} onChange={set('salesPerMonth')} suffix="шт" step={10} />
      </div>
      <Result rows={[
        ['Затраты FBO на единицу', fmt(fboCost) + ' ₽'],
        ['Затраты FBS на единицу', fmt(fbsCost) + ' ₽'],
        ['Выгоднее', fboCost <= fbsCost ? 'FBO' : 'FBS', 'ok'],
        ['Разница за месяц', fmt(Math.abs(diff)) + ' ₽ в пользу ' + (diff > 0 ? 'FBO' : 'FBS')]
      ]} note="Помимо денег учитывайте: FBO обычно даёт более быструю доставку (выше конверсия и позиции), FBS — контроль остатков и гибкость ассортимента. Часто оптимальна связка: топы на FBO, длинный хвост на FBS." />
    </>
  );
}

/* 11. Точка безубыточности по SKU */
function BreakEvenCalc() {
  const [v, setV] = useState({ fixCosts: 120000, price: 1500, varCost: 1180 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const cm = v.price - v.varCost;
  const beUnits = cm > 0 ? v.fixCosts / cm : NaN;
  const beRevenue = beUnits * v.price;
  return (
    <>
      <div className="calc-grid">
        <Num label="Постоянные затраты в месяц (команда, фотостудия, подписки)" value={v.fixCosts} onChange={set('fixCosts')} suffix="₽" step={5000} />
        <Num label="Цена продажи" value={v.price} onChange={set('price')} suffix="₽" step={50} />
        <Num label="Переменные затраты на единицу (закупка, комиссия, логистика, реклама)" value={v.varCost} onChange={set('varCost')} suffix="₽" step={10} />
      </div>
      <Result rows={[
        ['Маржинальная прибыль с единицы', fmt(cm) + ' ₽', cm > 0 ? 'ok' : 'bad'],
        ['Точка безубыточности', fmt(Math.ceil(beUnits)) + ' шт/мес'],
        ['В выручке', fmt(beRevenue) + ' ₽/мес']
      ]} note="Точка безубыточности = Постоянные затраты / (Цена − Переменные затраты). Всё, что продано сверх этого объёма, формирует прибыль бизнеса." />
    </>
  );
}

/* 12. Налоги и чистая прибыль */
function TaxCalc() {
  const [v, setV] = useState({ revenue: 1000000, costs: 780000, mode: 6 });
  const set = (k) => (x) => setV({ ...v, [k]: x });
  const tax6 = v.revenue * 0.06;
  const base = Math.max(0, v.revenue - v.costs);
  const tax15 = Math.max(base * 0.15, v.revenue * 0.01);
  const profit6 = v.revenue - v.costs - tax6;
  const profit15 = v.revenue - v.costs - tax15;
  return (
    <>
      <div className="calc-grid">
        <Num label="Выручка за период (перечисления МП + удержания)" value={v.revenue} onChange={set('revenue')} suffix="₽" step={50000} />
        <Num label="Подтверждённые расходы" value={v.costs} onChange={set('costs')} suffix="₽" step={50000} />
      </div>
      <Result rows={[
        ['УСН 6% «Доходы»: налог', fmt(tax6) + ' ₽'],
        ['УСН 6%: чистая прибыль', fmt(profit6) + ' ₽', profit6 >= profit15 ? 'ok' : ''],
        ['УСН 15% «Доходы − расходы»: налог', fmt(tax15) + ' ₽'],
        ['УСН 15%: чистая прибыль', fmt(profit15) + ' ₽', profit15 > profit6 ? 'ok' : ''],
        ['Выгоднее', profit6 >= profit15 ? 'УСН 6% «Доходы»' : 'УСН 15% «Доходы − расходы»', 'ok']
      ]} note="Важно: налоговая база на УСН — вся сумма продаж покупателям, а не то, что маркетплейс перечислил после удержания комиссии. Ставки региональные и меняются — сверяйтесь с актуальным законодательством и бухгалтером. Актуальность информации: сентябрь 2026." />
    </>
  );
}

const CALCULATORS = [
  { id: 'unit', title: '1. Юнит-экономика товара', desc: 'Полный расчёт прибыли и маржи с единицы с учётом комиссии, логистики, невыкупов, рекламы и налога', C: UnitEconomics },
  { id: 'minprice', title: '2. Минимальная цена продажи', desc: 'Точка безубыточности и минимальная цена под целевую маржу', C: MinPrice },
  { id: 'promo', title: '3. Калькулятор акции и скидки', desc: 'Сколько нужно дополнительных продаж, чтобы скидка окупилась', C: PromoCalc },
  { id: 'drr', title: '4. ДРР и ROAS', desc: 'Эффективность рекламы: доля рекламных расходов и возврат на рекламу', C: DrrCalc },
  { id: 'stock', title: '5. Оборачиваемость и точка заказа', desc: 'На сколько дней хватит запаса и когда пора заказывать', C: StockCalc },
  { id: 'supply', title: '6. Объём поставки', desc: 'Сколько отгружать на склад с учётом роста и товаров в пути', C: SupplyCalc },
  { id: 'buyout', title: '7. Цена невыкупов', desc: 'Сколько стоит процент выкупа и что он добавляет к себестоимости', C: BuyoutCalc },
  { id: 'funnel', title: '8. Воронка продаж', desc: 'Показы → клики → корзины → заказы → выкупы → выручка', C: FunnelCalc },
  { id: 'decomp', title: '9. Декомпозиция плана', desc: 'От целевой прибыли к нужным показам и кликам', C: DecompCalc },
  { id: 'fbofbs', title: '10. FBO vs FBS', desc: 'Какая схема работы выгоднее для конкретного товара', C: FboFbsCalc },
  { id: 'breakeven', title: '11. Точка безубыточности бизнеса', desc: 'Сколько продаж покрывает постоянные затраты', C: BreakEvenCalc },
  { id: 'tax', title: '12. Налоги: УСН 6% vs 15%', desc: 'Сравнение налоговых режимов и чистая прибыль', C: TaxCalc }
];

export default function CalculatorsPage() {
  return (
    <div>
      <h1>Калькуляторы</h1>
      <p style={{ color: 'var(--muted)' }}>12 рабочих инструментов селлера. Все расчёты происходят в браузере, данные никуда не отправляются.
        Подставляйте свои цифры — формулы те же, что разбираются в уроках.</p>
      {CALCULATORS.map(({ id, title, desc, C }) => (
        <Calc key={id} title={title} desc={desc}><C /></Calc>
      ))}
    </div>
  );
}
