import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { loadState } from '../services/storage.js';
import { LESSON_MAP, MODULE_MAP } from '../data/courseIndex.js';

export default function NotesPage() {
  const state = useMemo(() => loadState(), []);
  const notes = Object.entries(state.notes || {}).filter(([, v]) => v && v.text && v.text.trim());
  return (
    <div>
      <h1>Мои заметки</h1>
      {notes.length === 0 && (
        <p className="panel">Заметок пока нет. Открывайте любой урок и записывайте мысли во вкладке «Заметка» — все они соберутся здесь.</p>
      )}
      {notes.map(([lessonId, n]) => {
        const l = LESSON_MAP[lessonId];
        return (
          <div className="panel" key={lessonId}>
            <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
              <Link to={`/lesson/${lessonId}`}><b>{l ? l.title : lessonId}</b></Link>
              <span style={{ fontSize: '.78rem', color: 'var(--muted)' }}>
                {l ? MODULE_MAP[l.moduleId]?.title : ''}{n.date ? ' · ' + new Date(n.date).toLocaleDateString('ru-RU') : ''}
              </span>
            </div>
            <p style={{ whiteSpace: 'pre-line', margin: '8px 0 0', fontSize: '.92rem' }}>{n.text}</p>
          </div>
        );
      })}
    </div>
  );
}
