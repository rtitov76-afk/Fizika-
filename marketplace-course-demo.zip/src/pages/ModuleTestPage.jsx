import React, { useMemo, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MODULE_MAP, moduleBank } from '../data/courseIndex.js';
import { updateState, logActivity } from '../services/storage.js';
import { sampleQuestions } from '../services/quiz.js';
import QuizRunner from '../components/QuizRunner.jsx';

export default function ModuleTestPage() {
  const { moduleId } = useParams();
  const mod = MODULE_MAP[moduleId];
  const bank = useMemo(() => (mod ? moduleBank(mod) : []), [mod]);
  const [questions, setQuestions] = useState(null);
  const [result, setResult] = useState(null);
  if (!mod) return <div className="panel">Модуль не найден. <Link to="/course">К программе</Link></div>;

  const show = Math.min(mod.moduleTest?.show ?? 15, bank.length);
  const pass = mod.moduleTest?.pass ?? 70;

  function start() {
    setResult(null);
    setQuestions(sampleQuestions(bank, show));
  }

  function onFinish(res) {
    updateState((st) => {
      st.modules[mod.id] = st.modules[mod.id] || { attempts: [], bestScore: null, feedback: null };
      const m = st.modules[mod.id];
      m.attempts.push({ date: res.date, score: res.percent, correct: res.correct, total: res.total, timeSec: res.timeSec, wrong: res.wrong });
      if (m.bestScore == null || res.percent > m.bestScore) m.bestScore = res.percent;
    });
    logActivity('module_test', `Тест модуля ${mod.order}: ${mod.title}`, res.percent);
    setResult(res);
  }

  return (
    <div>
      <p><Link to={`/module/${mod.id}`}>← Модуль {mod.order}. {mod.title}</Link></p>
      <h1>Тест модуля {mod.order}</h1>
      {!questions && (
        <div className="panel">
          <p>{show} вопросов случайной выборкой из банка ({bank.length} вопросов). Порог сдачи — {pass}%.
            При повторной попытке вопросы будут другими.</p>
          <button className="btn" onClick={start}>Начать тест</button>
        </div>
      )}
      {questions && (
        <QuizRunner
          key={questions.map((q) => q.id).join(',')}
          questions={questions}
          title={`Тест модуля ${mod.order}. ${mod.title}`}
          pass={pass}
          onFinish={onFinish}
        />
      )}
      {result && (
        <div className="panel no-print">
          <button className="btn secondary" onClick={start}>Пройти ещё раз (новые вопросы)</button>{' '}
          <Link className="btn" to={`/module/${mod.id}`}>К модулю</Link>
        </div>
      )}
    </div>
  );
}
