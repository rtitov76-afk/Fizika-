import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { loadState } from '../services/storage.js';
import { MODULES } from '../data/courseIndex.js';
import { lessonStatus, STATUS_META, moduleProgress } from '../services/progress.js';

export default function ResultsPage() {
  const state = useMemo(() => loadState(), []);
  const attempts = (state.activity || []).filter((a) => ['quiz', 'module_test', 'exam', 'diagnostic', 'trainer'].includes(a.type));
  return (
    <div>
      <h1>Результаты и история</h1>

      <div className="panel">
        <h3>Хронология активности</h3>
        {attempts.length === 0 && <p style={{ color: 'var(--muted)' }}>История появится после первых тестов.</p>}
        <div className="timeline">
          {attempts.map((a, i) => (
            <div className="timeline-item" key={i}>
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
                <span style={{ fontSize: '.9rem' }}>{a.label}</span>
                <span>
                  {a.value != null && <span className={'badge ' + (a.value >= 70 ? 'st-passed' : 'st-failed')}>{a.value}%</span>}
                  {' '}<span style={{ fontSize: '.78rem', color: 'var(--muted)' }}>{new Date(a.date).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="panel">
        <h3>Сводка по модулям</h3>
        <div style={{ overflowX: 'auto' }}>
          <table className="tbl">
            <thead>
              <tr><th>Модуль</th><th>Уроки</th><th>Тест модуля</th><th>Статус</th></tr>
            </thead>
            <tbody>
              {MODULES.map((m) => {
                const mp = moduleProgress(state, m);
                return (
                  <tr key={m.id}>
                    <td><Link to={`/module/${m.id}`}>{m.order}. {m.title}</Link></td>
                    <td>{mp.passed}/{mp.total}</td>
                    <td>{mp.testScore != null ? mp.testScore + '%' : '—'}</td>
                    <td>{mp.percent === 100 && mp.testPassed ? '✓ Пройден' : mp.passed > 0 ? '◔ В процессе' : '○ Не начат'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <div className="panel">
        <h3>Попытки по урокам</h3>
        <div style={{ overflowX: 'auto' }}>
          <table className="tbl">
            <thead><tr><th>Урок</th><th>Попыток</th><th>Лучший</th><th>Статус</th></tr></thead>
            <tbody>
              {MODULES.flatMap((m) => m.lessons).filter((l) => state.lessons[l.id]?.attempts?.length).map((l) => {
                const rec = state.lessons[l.id];
                const st = lessonStatus(state, l);
                return (
                  <tr key={l.id}>
                    <td><Link to={`/lesson/${l.id}`}>{l.title}</Link></td>
                    <td>{rec.attempts.length}</td>
                    <td>{rec.bestScore}%</td>
                    <td>{STATUS_META[st].icon} {STATUS_META[st].label}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
