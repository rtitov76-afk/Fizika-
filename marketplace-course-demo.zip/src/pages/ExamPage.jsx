import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { allQuestions } from '../data/courseIndex.js';
import { buildExam } from '../services/quiz.js';
import { updateState, logActivity, loadState } from '../services/storage.js';
import { overallProgress } from '../services/progress.js';
import QuizRunner from '../components/QuizRunner.jsx';

const EXAM_TOTAL = 30; // демо (в полной версии 90)
const EXAM_TIME = 40 * 60; // демо (в полной версии 120 минут)

export default function ExamPage() {
  const [state, setState] = useState(() => loadState());
  const [questions, setQuestions] = useState(null);
  const op = overallProgress(state);
  const attempts = state.exam.attempts;
  const best = attempts.length ? Math.max(...attempts.map((a) => a.percent)) : null;

  function start() {
    setQuestions(buildExam(allQuestions(), EXAM_TOTAL));
  }

  function onFinish(res) {
    const s = updateState((st) => {
      st.exam.attempts.push({ date: res.date, percent: res.percent, correct: res.correct, total: res.total, timeSec: res.timeSec, wrong: res.wrong });
    });
    logActivity('exam', 'Итоговый экзамен', res.percent);
    setState(s);
    setQuestions(null);
  }

  if (questions) {
    return (
      <QuizRunner
        questions={questions}
        title="Итоговый экзамен"
        pass={70}
        timeLimitSec={EXAM_TIME}
        onFinish={onFinish}
      />
    );
  }

  return (
    <div>
      <h1>Итоговый экзамен</h1>
      <div className="panel">
        <p><b>{EXAM_TOTAL} вопросов · 120 минут · порог сдачи 70%.</b></p>
        <p style={{ fontSize: '.92rem' }}>Структура: ~20% теория, ~30% расчётные задачи, ~30% мини-кейсы, ~20% управленческие решения.
          Вопросы выбираются случайно из банка всего курса — каждая попытка уникальна.</p>
        {op.percent < 50 && (
          <div className="callout">
            <p style={{ margin: 0 }}>Вы прошли {op.percent}% уроков. Экзамен доступен в любой момент, но рекомендуем
              сдавать его после основных модулей — результат входит в Marketplace Score с весом 20%.</p>
          </div>
        )}
        <button className="btn" onClick={start}>Начать экзамен</button>
      </div>
      {attempts.length > 0 && (
        <div className="panel">
          <h3>Ваши попытки</h3>
          <p>Лучший результат: <b>{best}%</b> {best >= 70 ? '— экзамен сдан ✓' : '— экзамен пока не сдан'}</p>
          <table className="tbl">
            <thead><tr><th>Дата</th><th>Результат</th><th>Верно</th><th>Время</th></tr></thead>
            <tbody>
              {attempts.slice().reverse().map((a, i) => (
                <tr key={i}>
                  <td>{new Date(a.date).toLocaleString('ru-RU', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' })}</td>
                  <td><span className={'badge ' + (a.percent >= 70 ? 'st-passed' : 'st-failed')}>{a.percent}%</span></td>
                  <td>{a.correct}/{a.total}</td>
                  <td>{Math.round(a.timeSec / 60)} мин</td>
                </tr>
              ))}
            </tbody>
          </table>
          {best >= 70 && <p><Link className="btn" to="/certificate">Перейти к сертификату →</Link></p>}
        </div>
      )}
    </div>
  );
}
