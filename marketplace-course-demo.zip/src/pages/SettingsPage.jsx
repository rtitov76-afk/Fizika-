import React, { useRef, useState } from 'react';
import { loadState, updateState, exportState, importState, resetState } from '../services/storage.js';

export default function SettingsPage() {
  const [state, setState] = useState(() => loadState());
  const [msg, setMsg] = useState('');
  const fileRef = useRef(null);

  function setName(name) {
    setState(updateState((st) => { st.profile.name = name; }));
  }

  function onImport(e) {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const s = importState(reader.result);
        setState(s);
        setMsg('✓ Прогресс успешно импортирован.');
      } catch (err) {
        setMsg('✕ Ошибка импорта: ' + err.message);
      }
    };
    reader.readAsText(f);
    e.target.value = '';
  }

  function onReset() {
    if (window.confirm('Удалить весь прогресс, заметки и результаты? Это действие необратимо. Рекомендуем сначала сделать экспорт.')) {
      setState(resetState());
      setMsg('Прогресс сброшен.');
    }
  }

  return (
    <div>
      <h1>Настройки</h1>

      <div className="panel">
        <h3>Профиль</h3>
        <div className="field">
          <label>Ваше имя (для приветствия и сертификата)</label>
          <input value={state.profile.name || ''} placeholder="Иван Иванов" onChange={(e) => setName(e.target.value)} />
        </div>
      </div>

      <div className="panel">
        <h3>Данные и прогресс</h3>
        <p style={{ fontSize: '.9rem', color: 'var(--muted)' }}>Весь прогресс хранится локально в вашем браузере (localStorage) и никуда не отправляется.
          Экспортируйте файл, чтобы перенести прогресс на другое устройство или сохранить резервную копию.</p>
        <button className="btn" onClick={() => exportState()}>⬇ Экспорт прогресса (JSON)</button>{' '}
        <button className="btn secondary" onClick={() => fileRef.current?.click()}>⬆ Импорт прогресса</button>{' '}
        <button className="btn danger" onClick={onReset}>Сбросить всё</button>
        <input ref={fileRef} type="file" accept="application/json" style={{ display: 'none' }} onChange={onImport} />
        {msg && <p style={{ marginTop: 10 }}>{msg}</p>}
      </div>

      <div className="panel">
        <h3>О приложении</h3>
        <p style={{ fontSize: '.9rem' }}>Курс «Продажи и продвижение на маркетплейсах Ozon и Wildberries: от запуска до управления прибылью».
          Интерактивное учебное приложение: 31 модуль, банки вопросов со случайной выборкой, калькуляторы, тренажёры,
          диагностика, экзамен и сертификат.</p>
        <p style={{ fontSize: '.85rem', color: 'var(--muted)' }}>Работает полностью офлайн после загрузки. Архитектура хранения готова к подключению
          облачной синхронизации (Supabase/Firebase) — модуль storage.js изолирует все операции с данными.
          Актуальность справочной информации о тарифах: сентябрь 2026.</p>
      </div>
    </div>
  );
}
