import React, { useMemo, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { MODULE_MAP, moduleBank } from '../data/courseIndex.js';
import { loadState, updateState } from '../services/storage.js';
import { lessonStatus, STATUS_META, moduleProgress } from '../services/progress.js';
import ProgressBar from '../components/ProgressBar.jsx';

const FB_FIELDS = [
  ['useful', 'Полезность'], ['clarity', 'Понятность'], ['practical', 'Практичность'],
  ['difficulty', 'Сложность'], ['examples', 'Качество примеров']
];

export default function ModulePage() {
  const { moduleId } = useParams();
  const mod = MODULE_MAP[moduleId];
  const [state, setState] = useState(() => loadState());
  const bank = useMemo(() => (mod ? moduleBank(mod) : []), [mod]);
  if (!mod) return <div className="panel">Модуль не найден. <Link to="/course">К программе курса</Link></div>;
  const mp = moduleProgress(state, mod);
  const fb = state.modules[mod.id]?.feedback;

  function saveFeedback(values) {
    const s = updateState((st) => {
      st.modules[mod.id] = st.modules[mod.id] || { attempts: [], bestScore: null, feedback: null };
      st.modules[mod.id].feedback = { ...values, date: new Date().toISOString() };
    });
    setState(s);
  }

  return (
    <div>
      <p><Link to="/course">← Программа курса</Link></p>
      <h1>Модуль {mod.order}. {mod.title}</h1>
      <p style={{ color: 'var(--muted)' }}>{mod.description}</p>
      <div className="panel">
        <ProgressBar percent={mp.percent} />
        <p style={{ fontSize: '.85rem', color: 'var(--muted)' }}>{mp.passed} из {mp.total} уроков пройдено</p>
        {mod.lessons.map((l) => {
          const st = lessonStatus(state, l);
          const meta = STATUS_META[st];
          const best = state.lessons[l.id]?.bestScore;
          return (
            <div className="lesson-list-item" key={l.id}>
              <div>
                <Link to={`/lesson/${l.id}`}><b>{l.title}</b></Link>
                <div style={{ fontSize: '.8rem', color: 'var(--muted)' }}>≈ {l.duration || 20} мин{best != null ? ` · лучший результат: ${best}%` : ''}</div>
              </div>
              <span className={'badge ' + meta.cls}>{meta.icon} {meta.label}</span>
            </div>
          );
        })}
      </div>

      <div className="panel">
        <h3>Тест по модулю</h3>
        <p style={{ fontSize: '.9rem' }}>
          {mod.moduleTest?.show ?? 15} вопросов случайной выборкой из банка ({bank.length} вопросов). Порог — {mod.moduleTest?.pass ?? 70}%.
          {mp.testScore != null && <> Ваш лучший результат: <b>{mp.testScore}%</b>.</>}
        </p>
        <Link className="btn" to={`/module/${mod.id}/test`}>Начать тест модуля</Link>
      </div>

      <div className="panel">
        <h3>Оцените модуль</h3>
        {fb ? (
          <p style={{ color: 'var(--muted)' }}>Спасибо! Ваша оценка сохранена: {FB_FIELDS.map(([k, l]) => `${l} — ${fb[k]}`).join(' · ')}.
            {' '}<button className="btn small secondary" onClick={() => saveFeedback(null) || setState(loadState())}>Изменить</button></p>
        ) : (
          <ModuleFeedbackForm onSave={saveFeedback} />
        )}
      </div>
    </div>
  );
}

function ModuleFeedbackForm({ onSave }) {
  const [v, setV] = useState({ useful: 8, clarity: 8, practical: 8, difficulty: 5, examples: 8 });
  return (
    <div>
      {FB_FIELDS.map(([k, label]) => (
        <div className="field" key={k}>
          <label>{label}: <b>{v[k]}</b>/10</label>
          <input type="range" min="1" max="10" value={v[k]} onChange={(e) => setV({ ...v, [k]: Number(e.target.value) })} />
        </div>
      ))}
      <button className="btn small" onClick={() => onSave(v)}>Сохранить оценку</button>
    </div>
  );
}
