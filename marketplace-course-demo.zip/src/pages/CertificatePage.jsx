import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { loadState, updateState } from '../services/storage.js';
import { finalScore, overallProgress, isCourseComplete } from '../services/progress.js';

export default function CertificatePage() {
  const [state, setState] = useState(() => loadState());
  const fs = useMemo(() => finalScore(state), [state]);
  const op = overallProgress(state);
  const done = isCourseComplete(state);
  const examBest = state.exam.attempts.length ? Math.max(...state.exam.attempts.map((a) => a.percent)) : null;

  function setName(name) {
    const s = updateState((st) => { st.profile.name = name; });
    setState(s);
  }

  if (!done) {
    return (
      <div>
        <h1>Сертификат</h1>
        <div className="panel">
          <p>Сертификат откроется после выполнения условий:</p>
          <div className="lesson-list-item">
            <span>Пройдено ≥ 80% уроков курса</span>
            <span className={'badge ' + (op.percent >= 80 ? 'st-passed' : 'st-failed')}>{op.percent}% / 80%</span>
          </div>
          <div className="lesson-list-item">
            <span>Итоговый экзамен сдан на ≥ 70%</span>
            <span className={'badge ' + (examBest >= 70 ? 'st-passed' : 'st-failed')}>{examBest != null ? examBest + '%' : 'не сдан'}</span>
          </div>
          <p style={{ marginTop: 12 }}>
            <Link className="btn" to="/course">Продолжить обучение</Link>{' '}
            <Link className="btn secondary" to="/exam">К экзамену</Link>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="no-print" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
        <h1 style={{ margin: 0 }}>Сертификат</h1>
        <button className="btn" onClick={() => window.print()}>🖨 Печать / Сохранить в PDF</button>
      </div>
      <div className="panel no-print">
        <div className="field">
          <label>Имя и фамилия на сертификате</label>
          <input value={state.profile.name || ''} placeholder="Иван Иванов" onChange={(e) => setName(e.target.value)} />
        </div>
      </div>

      <div className="cert">
        <div style={{ fontSize: '.85rem', letterSpacing: 2, textTransform: 'uppercase', color: 'var(--muted)' }}>Сертификат о прохождении курса</div>
        <h2 style={{ fontSize: '1.9rem', margin: '18px 0 6px' }}>{state.profile.name || '______________________'}</h2>
        <p style={{ margin: '0 0 14px' }}>успешно завершил(а) курс</p>
        <h3 style={{ fontSize: '1.15rem', margin: '0 0 18px' }}>«Продажи и продвижение на маркетплейсах Ozon и Wildberries:<br />от запуска до управления прибылью»</h3>
        <div style={{ display: 'flex', justifyContent: 'center', gap: 40, flexWrap: 'wrap', margin: '18px 0' }}>
          <div><b style={{ fontSize: '1.5rem' }}>{fs.score}/100</b><div style={{ fontSize: '.8rem', color: 'var(--muted)' }}>Marketplace Score</div></div>
          <div><b style={{ fontSize: '1.5rem' }}>{fs.level}</b><div style={{ fontSize: '.8rem', color: 'var(--muted)' }}>уровень</div></div>
          <div><b style={{ fontSize: '1.5rem' }}>{op.passed}</b><div style={{ fontSize: '.8rem', color: 'var(--muted)' }}>уроков пройдено</div></div>
        </div>
        <p style={{ fontSize: '.85rem', color: 'var(--muted)' }}>
          31 модуль · юнит-экономика · реклама · SEO · логистика · аналитика · финансы · управление
        </p>
        <p style={{ fontSize: '.85rem' }}>Дата выдачи: {new Date().toLocaleDateString('ru-RU')}</p>
      </div>

      <p className="no-print" style={{ color: 'var(--muted)', fontSize: '.85rem' }}>
        Для сохранения в PDF нажмите «Печать» и выберите «Сохранить как PDF» в диалоге печати браузера.
      </p>
    </div>
  );
}
