import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { DIAGNOSTIC } from '../data/diagnostic.js';
import { updateState, logActivity, loadState } from '../services/storage.js';
import { scoreQuiz, checkAnswer, sampleQuestions } from '../services/quiz.js';
import { COMPETENCY_MAP, DIAG_LEVELS } from '../data/competencies.js';
import QuizRunner from '../components/QuizRunner.jsx';
import CompetencyBars from '../components/CompetencyBars.jsx';

export default function DiagnosticPage() {
  const [state, setState] = useState(() => loadState());
  const [questions, setQuestions] = useState(null);
  const diag = state.diagnostic;

  function start() {
    setQuestions(sampleQuestions(DIAGNOSTIC, DIAGNOSTIC.length));
  }

  function onFinish(res) {
    // byCompetency: score per competency from answered questions
    const byComp = {};
    questions.forEach((q, i) => {
      const comp = q.comp || 'strategy';
      byComp[comp] = byComp[comp] || { correct: 0, total: 0 };
      byComp[comp].total += 1;
      if (checkAnswer(q, res.answers[i])) byComp[comp].correct += 1;
    });
    const byCompetency = {};
    Object.entries(byComp).forEach(([k, v]) => {
      byCompetency[k] = Math.round((v.correct / v.total) * 100);
    });
    const level = DIAG_LEVELS.find((l) => res.percent >= l.min) || DIAG_LEVELS[DIAG_LEVELS.length - 1];
    const s = updateState((st) => {
      st.diagnostic = { date: res.date, score: res.percent, level: level.name, byCompetency, timeSec: res.timeSec };
    });
    logActivity('diagnostic', 'Входная диагностика', res.percent);
    setState(s);
    setQuestions(null);
  }

  if (questions) {
    return (
      <QuizRunner
        questions={questions}
        title="Входная диагностика"
        pass={0}
        timeLimitSec={40 * 60}
        onFinish={onFinish}
      />
    );
  }

  return (
    <div>
      <h1>Входная диагностика</h1>
      {!diag && (
        <div className="panel">
          <p>{DIAGNOSTIC.length} вопросов по всем ключевым областям: стратегия, юнит-экономика, реклама,
            SEO, логистика, аналитика, финансы. Ограничение — 40 минут.</p>
          <p style={{ color: 'var(--muted)' }}>Диагностика определит ваш уровень и слабые зоны — приложение построит
            персональные рекомендации, с каких модулей начать. Результат не влияет на итоговую оценку курса.</p>
          <button className="btn" onClick={start}>Начать диагностику</button>
        </div>
      )}
      {diag && (
        <>
          <div className="panel">
            <h3>Ваш результат: {diag.score}% — уровень «{diag.level}»</h3>
            <p style={{ color: 'var(--muted)' }}>Пройдено {new Date(diag.date).toLocaleDateString('ru-RU')}.
              Ниже — ваш стартовый профиль по компетенциям. Он используется для рекомендаций на главной странице.</p>
            <CompetencyBars scores={diag.byCompetency} />
          </div>
          <div className="panel">
            <h3>Слабые зоны на старте</h3>
            {Object.entries(diag.byCompetency).filter(([, v]) => v < 70).sort((a, b) => a[1] - b[1]).map(([k, v]) => (
              <div key={k} className="lesson-list-item">
                <span>{COMPETENCY_MAP[k]?.name || k}</span>
                <span className="badge st-failed">{v}%</span>
              </div>
            ))}
            {Object.values(diag.byCompetency).every((v) => v >= 70) && (
              <p style={{ color: 'var(--muted)' }}>Явных слабых зон нет — отличный старт!</p>
            )}
            <p style={{ marginTop: 10 }}>
              <Link className="btn" to="/course">К программе курса</Link>{' '}
              <button className="btn secondary" onClick={start}>Пройти диагностику заново</button>
            </p>
          </div>
        </>
      )}
    </div>
  );
}
