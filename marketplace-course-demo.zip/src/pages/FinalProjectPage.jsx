import React, { useState } from 'react';
import { loadState, updateState } from '../services/storage.js';

const BLOCKS = [
  { id: 'product', title: '1. Продукт и ниша', hint: 'Какой товар/категория, почему именно она: ёмкость, конкуренция, маржинальность, сезонность. Данные аналитики, а не ощущения.' },
  { id: 'economics', title: '2. Юнит-экономика', hint: 'Полный расчёт: закупка, комиссия, логистика, невыкупы, реклама, налоги → прибыль с единицы и маржа. Целевые и минимально допустимые значения.' },
  { id: 'platforms', title: '3. Площадки и схема работы', hint: 'Ozon / WB / обе. FBO, FBS или гибрид — и почему. План выхода: с какой площадки начинаете и когда добавляете вторую.' },
  { id: 'assortment', title: '4. Ассортиментная политика', hint: 'Стартовая матрица SKU, план расширения по кварталам, критерии вывода неудачных позиций (когда режем).' },
  { id: 'promotion', title: '5. Продвижение', hint: 'SEO-стратегия карточек, рекламные инструменты по этапам (запуск → рост → удержание), предельный ДРР, работа с отзывами, участие в акциях.' },
  { id: 'logistics', title: '6. Логистика и запасы', hint: 'Цепочка поставок, сроки, точки заказа, страховой запас, распределение по складам, план на пиковые сезоны.' },
  { id: 'finance', title: '7. Финансовый план на 12 месяцев', hint: 'Помесячно: выручка, затраты, прибыль, потребность в оборотном капитале. Точка безубыточности бизнеса и срок окупаемости вложений.' },
  { id: 'team', title: '8. Команда и процессы', hint: 'Кто и что делает на каждом этапе роста: сам / фрилансеры / штат. KPI ролей. Какие процессы автоматизируете (API, сервисы аналитики).' },
  { id: 'risks', title: '9. Риски и план Б', hint: 'Топ-5 рисков (блокировка, демпинг, рост тарифов, кассовый разрыв, out-of-stock) и конкретные действия по каждому.' },
  { id: 'kpi', title: '10. Цели и контрольные точки', hint: 'Цели по кварталам: выручка, прибыль, SKU, доля площадок. Что смотрите еженедельно (WBR) и по каким триггерам меняете план.' }
];

export default function FinalProjectPage() {
  const [state, setState] = useState(() => loadState());
  const fp = state.finalProject || { blocks: {}, done: false };
  const [local, setLocal] = useState(fp.blocks || {});
  const filled = BLOCKS.filter((b) => (local[b.id] || '').trim().length >= 100).length;

  function save(markDone) {
    const s = updateState((st) => {
      st.finalProject = { blocks: local, done: markDone ?? fp.done, date: new Date().toISOString() };
    });
    setState(s);
  }

  return (
    <div>
      <div className="no-print" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
        <h1 style={{ margin: 0 }}>Финальный проект: стратегия на 12 месяцев</h1>
        <button className="btn secondary" onClick={() => window.print()}>🖨 Печать / PDF</button>
      </div>
      <p style={{ color: 'var(--muted)' }}>Итоговая работа курса — полная стратегия вашего (или гипотетического) магазина.
        Заполняйте блоки по мере прохождения модулей: каждый блок опирается на конкретные уроки.
        Черновик сохраняется автоматически при нажатии «Сохранить».</p>

      <div className="panel no-print">
        <b>Заполнено содержательно: {filled} из {BLOCKS.length} блоков</b>
        <p style={{ fontSize: '.85rem', color: 'var(--muted)', margin: '4px 0 0' }}>Блок засчитывается, когда в нём не меньше ~100 символов осмысленного текста.</p>
      </div>

      {BLOCKS.map((b) => (
        <div className="panel" key={b.id}>
          <h3 style={{ marginTop: 0 }}>{b.title}</h3>
          <p style={{ fontSize: '.85rem', color: 'var(--muted)' }}>{b.hint}</p>
          <textarea
            className="no-print-border"
            rows={6}
            style={{ width: '100%' }}
            value={local[b.id] || ''}
            onChange={(e) => setLocal({ ...local, [b.id]: e.target.value })}
            placeholder="Ваш текст…"
          />
        </div>
      ))}

      <div className="panel no-print">
        <button className="btn" onClick={() => save()}>Сохранить черновик</button>{' '}
        {filled === BLOCKS.length && !fp.done && (
          <button className="btn" onClick={() => save(true)}>✓ Отметить проект завершённым</button>
        )}
        {fp.done && <span className="badge st-passed">✓ Проект завершён</span>}
      </div>
    </div>
  );
}
