import React, { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { loadState } from '../services/storage.js';
import { overallProgress, finalScore, weakTopics, competencyScores, scoreBlocks } from '../services/progress.js';
import { MODULES } from '../data/courseIndex.js';
import { moduleProgress } from '../services/progress.js';
import { COMPETENCY_MAP } from '../data/competencies.js';

function buildAlerts(state) {
  const alerts = [];
  const op = overallProgress(state);
  const weak = weakTopics(state);
  const week = 7 * 24 * 3600 * 1000;
  const recent = (state.activity || []).filter((a) => Date.now() - new Date(a.date).getTime() < week);

  if (recent.length === 0 && op.passed > 0) {
    alerts.push({ sev: 'red', text: 'За последние 7 дней нет учебной активности. Регулярность важнее объёма: 2–3 урока в неделю достаточно.' });
  }
  if (weak.length >= 3) {
    alerts.push({ sev: 'red', text: `Накопилось ${weak.length} слабых тем. Не двигайтесь дальше, пока не закроете хотя бы половину — пробелы в базе умножают ошибки в продвинутых модулях.` });
  } else if (weak.length > 0) {
    alerts.push({ sev: 'yellow', text: `Есть ${weak.length} тема(ы) на повторение — загляните в раздел «Нужно повторить».` });
  }
  const failedModules = MODULES.filter((m) => {
    const mp = moduleProgress(state, m);
    return mp.testScore != null && !mp.testPassed;
  });
  if (failedModules.length) {
    alerts.push({ sev: 'yellow', text: 'Не сданы тесты модулей: ' + failedModules.map((m) => `«${m.title}»`).join(', ') + '. Перепройдите — вопросы будут новыми.' });
  }
  if (!state.diagnostic) {
    alerts.push({ sev: 'yellow', text: 'Входная диагностика не пройдена — рекомендации строятся только по порядку программы.' });
  }
  if (op.percent >= 80 && !state.exam.attempts.length) {
    alerts.push({ sev: 'green', text: 'Вы прошли более 80% курса — можно выходить на итоговый экзамен.' });
  }
  if (alerts.length === 0) {
    alerts.push({ sev: 'green', text: 'Всё в порядке: активность регулярная, слабых тем нет. Продолжайте по программе.' });
  }
  return alerts;
}

export default function ReportPage() {
  const state = useMemo(() => loadState(), []);
  const op = overallProgress(state);
  const fs = finalScore(state);
  const blocks = scoreBlocks(state);
  const comp = competencyScores(state);
  const alerts = buildAlerts(state);
  const week = 7 * 24 * 3600 * 1000;
  const recent = (state.activity || []).filter((a) => Date.now() - new Date(a.date).getTime() < week);
  const tests = recent.filter((a) => ['quiz', 'module_test', 'exam'].includes(a.type));
  const avgRecent = tests.length ? Math.round(tests.reduce((s, a) => s + (a.value || 0), 0) / tests.length) : null;
  const compEntries = Object.entries(comp).filter(([, v]) => v != null);
  const sorted = [...compEntries].sort((a, b) => b[1] - a[1]);

  return (
    <div>
      <div className="no-print" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
        <h1 style={{ margin: 0 }}>Weekly Business Review</h1>
        <button className="btn secondary" onClick={() => window.print()}>🖨 Печать / PDF</button>
      </div>
      <p style={{ color: 'var(--muted)' }}>Управленческий взгляд на ваше обучение — как директор смотрит на бизнес: факты, динамика, алерты, решения.
        Отчёт на {new Date().toLocaleDateString('ru-RU')}.</p>

      <div className="panel">
        <h3>⚠️ Управленческие алерты</h3>
        {alerts.map((a, i) => (
          <div key={i} className="lesson-list-item">
            <span style={{ fontSize: '.92rem' }}>{a.text}</span>
            <span className={'badge ' + (a.sev === 'red' ? 'st-failed' : a.sev === 'yellow' ? 'st-started' : 'st-passed')}>
              {a.sev === 'red' ? 'Критично' : a.sev === 'yellow' ? 'Внимание' : 'ОК'}
            </span>
          </div>
        ))}
      </div>

      <div className="grid4">
        <div className="panel"><b>{op.percent}%</b><div style={{ fontSize: '.8rem', color: 'var(--muted)' }}>прогресс курса</div></div>
        <div className="panel"><b>{fs.score}/100</b><div style={{ fontSize: '.8rem', color: 'var(--muted)' }}>Marketplace Score · {fs.level}</div></div>
        <div className="panel"><b>{tests.length}</b><div style={{ fontSize: '.8rem', color: 'var(--muted)' }}>тестов за 7 дней</div></div>
        <div className="panel"><b>{avgRecent == null ? '—' : avgRecent + '%'}</b><div style={{ fontSize: '.8rem', color: 'var(--muted)' }}>средний балл недели</div></div>
      </div>

      <div className="panel">
        <h3>Структура итоговой оценки</h3>
        <table className="tbl">
          <thead><tr><th>Блок</th><th>Вес</th><th>Ваш балл</th><th>Вклад</th></tr></thead>
          <tbody>
            <tr><td>Тесты уроков</td><td>20%</td><td>{blocks.lessonTests}%</td><td>{(blocks.lessonTests * 0.2).toFixed(1)}</td></tr>
            <tr><td>Тесты модулей</td><td>25%</td><td>{blocks.moduleTests}%</td><td>{(blocks.moduleTests * 0.25).toFixed(1)}</td></tr>
            <tr><td>Практические задания</td><td>20%</td><td>{blocks.practice}%</td><td>{(blocks.practice * 0.2).toFixed(1)}</td></tr>
            <tr><td>Бизнес-кейс</td><td>15%</td><td>{blocks.businessCase}%</td><td>{(blocks.businessCase * 0.15).toFixed(1)}</td></tr>
            <tr><td>Итоговый экзамен</td><td>20%</td><td>{blocks.finalExam}%</td><td>{(blocks.finalExam * 0.2).toFixed(1)}</td></tr>
          </tbody>
        </table>
      </div>

      <div className="grid2">
        <div className="panel">
          <h3>Сильные компетенции</h3>
          {sorted.slice(0, 5).map(([k, v]) => (
            <div key={k} className="lesson-list-item"><span>{COMPETENCY_MAP[k]?.name || k}</span><span className="badge st-passed">{v}%</span></div>
          ))}
          {sorted.length === 0 && <p style={{ color: 'var(--muted)' }}>Пока нет данных — пройдите первые тесты.</p>}
        </div>
        <div className="panel">
          <h3>Зоны роста</h3>
          {[...sorted].reverse().slice(0, 5).map(([k, v]) => (
            <div key={k} className="lesson-list-item"><span>{COMPETENCY_MAP[k]?.name || k}</span><span className={'badge ' + (v < 70 ? 'st-failed' : 'st-started')}>{v}%</span></div>
          ))}
          {sorted.length === 0 && <p style={{ color: 'var(--muted)' }}>Пока нет данных.</p>}
        </div>
      </div>

      <div className="panel">
        <h3>Шаблон WBR для вашего бизнеса</h3>
        <p style={{ fontSize: '.9rem', color: 'var(--muted)' }}>Та же логика еженедельного обзора применяется к магазину на маркетплейсе. Проводите каждую неделю в один и тот же день:</p>
        <table className="tbl">
          <thead><tr><th>Блок</th><th>Что смотреть</th><th>Триггер решения</th></tr></thead>
          <tbody>
            <tr><td>Деньги</td><td>Выручка, прибыль, маржа vs план и прошлая неделя</td><td>Отклонение &gt;10% — разбор причин</td></tr>
            <tr><td>Воронка</td><td>Показы, CTR, конверсия, выкуп по топ-SKU</td><td>Падение любого этапа &gt;15%</td></tr>
            <tr><td>Реклама</td><td>ДРР по кампаниям, ставки, доля рекламных заказов</td><td>ДРР выше предельного — резать/чинить</td></tr>
            <tr><td>Запасы</td><td>Оборачиваемость, дни до out-of-stock, товары в пути</td><td>&lt; срока поставки + буфер — заказ</td></tr>
            <tr><td>Контент и отзывы</td><td>Рейтинг, новые отзывы/вопросы, позиции по ключевым запросам</td><td>Рейтинг &lt;4.5 или потеря позиций</td></tr>
            <tr><td>Риски</td><td>Штрафы, блокировки, изменения правил площадок</td><td>Любое событие — план действий</td></tr>
          </tbody>
        </table>
      </div>

      <p className="no-print"><Link to="/analytics">→ Моя аналитика</Link> · <Link to="/weak">→ Нужно повторить</Link></p>
    </div>
  );
}
