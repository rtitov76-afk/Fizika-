import React, { useState, useEffect } from 'react';
import { Routes, Route, NavLink, useLocation } from 'react-router-dom';
import { addTime } from './services/storage.js';

import Dashboard from './pages/Dashboard.jsx';
import CoursePage from './pages/CoursePage.jsx';
import ModulePage from './pages/ModulePage.jsx';
import LessonPage from './pages/LessonPage.jsx';
import ModuleTestPage from './pages/ModuleTestPage.jsx';
import DiagnosticPage from './pages/DiagnosticPage.jsx';
import CalculatorsPage from './pages/CalculatorsPage.jsx';
import TrainersPage from './pages/TrainersPage.jsx';
import TrainerRunPage from './pages/TrainerRunPage.jsx';
import GlossaryPage from './pages/GlossaryPage.jsx';
import SearchPage from './pages/SearchPage.jsx';
import NotesPage from './pages/NotesPage.jsx';
import BookmarksPage from './pages/BookmarksPage.jsx';
import ResultsPage from './pages/ResultsPage.jsx';
import WeakTopicsPage from './pages/WeakTopicsPage.jsx';
import ExamPage from './pages/ExamPage.jsx';
import BusinessCasePage from './pages/BusinessCasePage.jsx';
import ReportPage from './pages/ReportPage.jsx';
import CertificatePage from './pages/CertificatePage.jsx';
import AnalyticsPage from './pages/AnalyticsPage.jsx';
import FeedbackPage from './pages/FeedbackPage.jsx';
import DocsPage from './pages/DocsPage.jsx';
import SettingsPage from './pages/SettingsPage.jsx';
import FinalProjectPage from './pages/FinalProjectPage.jsx';

const NAV = [
  { group: 'Обучение', items: [
    { to: '/', label: '🏠 Главная', end: true },
    { to: '/course', label: '📚 Курс' },
    { to: '/diagnostic', label: '🎯 Диагностика' },
    { to: '/weak', label: '🔁 Слабые темы' }
  ]},
  { group: 'Практика', items: [
    { to: '/calculators', label: '🧮 Калькуляторы' },
    { to: '/trainers', label: '🎮 Тренажёры' },
    { to: '/case', label: '💼 Бизнес-кейс' },
    { to: '/exam', label: '🎓 Итоговый экзамен' },
    { to: '/project', label: '🗺️ Финальный проект' }
  ]},
  { group: 'Мои данные', items: [
    { to: '/results', label: '📈 Мои результаты' },
    { to: '/analytics', label: '📊 Моя аналитика' },
    { to: '/report', label: '🏆 Итоговая оценка' },
    { to: '/certificate', label: '📜 Сертификат' },
    { to: '/notes', label: '📝 Мои заметки' },
    { to: '/bookmarks', label: '⭐ Избранное' }
  ]},
  { group: 'Справочник', items: [
    { to: '/search', label: '🔍 Поиск' },
    { to: '/glossary', label: '📖 Словарь' },
    { to: '/docs', label: '🔗 Документация' },
    { to: '/feedback', label: '💬 Оценка курса' },
    { to: '/settings', label: '⚙️ Настройки' }
  ]}
];

export default function App() {
  const [navOpen, setNavOpen] = useState(false);
  const location = useLocation();

  useEffect(() => { setNavOpen(false); window.scrollTo(0, 0); }, [location.pathname]);

  // учёт времени обучения (раз в минуту, пока вкладка активна)
  useEffect(() => {
    const t = setInterval(() => { if (!document.hidden) addTime(60); }, 60000);
    return () => clearInterval(t);
  }, []);

  return (
    <div>
      <div className="mobile-toggle no-print">
        <button onClick={() => setNavOpen(!navOpen)} aria-label="Открыть меню">☰ Меню</button>
        <strong>Marketplace Pro <span style={{ background: '#f59e0b', color: '#fff', borderRadius: 6, padding: '1px 7px', fontSize: '.7rem', verticalAlign: 'middle' }}>ДЕМО</span></strong>
      </div>
      <div className="layout">
        <aside className={'sidebar no-print' + (navOpen ? ' open' : '')} aria-label="Главное меню">
          <NavLink to="/" className="logo">Marketplace <span>Pro</span> <span style={{ background: '#f59e0b', color: '#fff', borderRadius: 6, padding: '1px 7px', fontSize: '.65rem' }}>ДЕМО</span></NavLink>
          <nav>
            {NAV.map((g) => (
              <div key={g.group}>
                <div className="navgroup">{g.group}</div>
                {g.items.map((it) => (
                  <NavLink key={it.to} to={it.to} end={it.end} className={({ isActive }) => (isActive ? 'active' : '')}>
                    {it.label}
                  </NavLink>
                ))}
              </div>
            ))}
          </nav>
        </aside>
        <main className="main">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/course" element={<CoursePage />} />
            <Route path="/module/:moduleId" element={<ModulePage />} />
            <Route path="/module/:moduleId/test" element={<ModuleTestPage />} />
            <Route path="/lesson/:lessonId" element={<LessonPage />} />
            <Route path="/diagnostic" element={<DiagnosticPage />} />
            <Route path="/calculators" element={<CalculatorsPage />} />
            <Route path="/trainers" element={<TrainersPage />} />
            <Route path="/trainers/:trainerId" element={<TrainerRunPage />} />
            <Route path="/glossary" element={<GlossaryPage />} />
            <Route path="/search" element={<SearchPage />} />
            <Route path="/notes" element={<NotesPage />} />
            <Route path="/bookmarks" element={<BookmarksPage />} />
            <Route path="/results" element={<ResultsPage />} />
            <Route path="/weak" element={<WeakTopicsPage />} />
            <Route path="/exam" element={<ExamPage />} />
            <Route path="/case" element={<BusinessCasePage />} />
            <Route path="/report" element={<ReportPage />} />
            <Route path="/certificate" element={<CertificatePage />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
            <Route path="/feedback" element={<FeedbackPage />} />
            <Route path="/docs" element={<DocsPage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/project" element={<FinalProjectPage />} />
            <Route path="*" element={<Dashboard />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
